"""ONVIF WS-Discovery (stdlib only): finds cameras on the local network."""
from __future__ import annotations

import re
import socket
import time
import uuid
from urllib.parse import unquote, urlsplit

PROBE = """<?xml version="1.0" encoding="UTF-8"?>
<e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope"
 xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing"
 xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery"
 xmlns:dn="http://www.onvif.org/ver10/network/wsdl">
<e:Header><w:MessageID>uuid:{mid}</w:MessageID>
<w:To e:mustUnderstand="true">urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>
<w:Action e:mustUnderstand="true">http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action></e:Header>
<e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe></e:Body></e:Envelope>"""


def parse_response(xml: str) -> dict | None:
    m = re.search(r"<[\w:]*XAddrs>([^<]+)<", xml)
    if not m:
        return None
    addrs = m.group(1).split()
    host = urlsplit(addrs[0]).hostname or ""
    port = urlsplit(addrs[0]).port or 80
    scopes = re.search(r"<[\w:]*Scopes[^>]*>([^<]*)<", xml)
    name = hardware = ""
    for s in (scopes.group(1).split() if scopes else []):
        if "/name/" in s:
            name = unquote(s.rsplit("/", 1)[-1])
        elif "/hardware/" in s:
            hardware = unquote(s.rsplit("/", 1)[-1])
    return {"ip": host, "port": port, "name": name, "hardware": hardware, "xaddrs": addrs}


def discover(timeout: float = 3.0) -> list[dict]:
    found: dict[str, dict] = {}
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 4)
    sock.settimeout(0.5)
    try:
        sock.sendto(PROBE.format(mid=uuid.uuid4()).encode(), ("239.255.255.250", 3702))
        end = time.time() + timeout
        while time.time() < end:
            try:
                data, _ = sock.recvfrom(65535)
            except socket.timeout:
                continue
            d = parse_response(data.decode("utf-8", "ignore"))
            if d and d["ip"]:
                found[d["ip"]] = d
    except OSError:
        pass
    finally:
        sock.close()
    return sorted(found.values(), key=lambda d: d["ip"])
