"""Threaded, self-reconnecting frame grabber (RTSP / HTTP-MJPEG / USB / file)."""
from __future__ import annotations

import logging
import os
import threading
import time

import cv2

from .brands import resolve_url

# TCP is far more reliable than UDP across NATs/Wi-Fi.
os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp")
log = logging.getLogger("vms.source")


def open_capture(src) -> cv2.VideoCapture:
    if isinstance(src, int):
        return cv2.VideoCapture(src)
    try:
        return cv2.VideoCapture(src, cv2.CAP_FFMPEG,
                                [cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 8000, cv2.CAP_PROP_READ_TIMEOUT_MSEC, 8000])
    except TypeError:  # older OpenCV without params support
        return cv2.VideoCapture(src, cv2.CAP_FFMPEG)


class CameraSource(threading.Thread):
    def __init__(self, cam: dict) -> None:
        super().__init__(daemon=True, name=f"src-{cam['id']}")
        self.cam = cam
        self.stop_evt = threading.Event()
        self._lock = threading.Lock()
        self._frame = None
        self._fid = 0
        self.online = False
        self.error = ""
        self.fps = 0.0
        self.size = (0, 0)
        self.url: str | int = ""

    def get(self):
        """-> (frame_id, frame|None). The returned frame must be treated as read-only."""
        with self._lock:
            return self._fid, self._frame

    def stop(self) -> None:
        self.stop_evt.set()

    def run(self) -> None:
        backoff = 2.0
        while not self.stop_evt.is_set():
            cap = None
            try:
                self.url = resolve_url(self.cam)
                cap = open_capture(self.url)
                if not cap.isOpened():
                    raise RuntimeError("cannot open stream (check address, credentials, brand/URL)")
                is_file = self.cam.get("brand") == "file"
                src_fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
                backoff, n, t0 = 2.0, 0, time.time()
                while not self.stop_evt.is_set():
                    ok, frame = cap.read()
                    if not ok or frame is None:
                        if is_file:  # loop test videos
                            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                            ok, frame = cap.read()
                        if not ok or frame is None:
                            raise RuntimeError("stream ended / read timeout")
                    with self._lock:
                        self._frame, self._fid = frame, self._fid + 1
                    self.online, self.error = True, ""
                    self.size = (frame.shape[1], frame.shape[0])
                    n += 1
                    if time.time() - t0 >= 2:
                        self.fps, n, t0 = n / (time.time() - t0), 0, time.time()
                    if is_file:
                        time.sleep(1.0 / max(1.0, min(src_fps, 60.0)))
            except Exception as e:  # noqa: BLE001 - keep the camera retrying forever
                self.error = str(e)[:200]
                log.warning("camera %s: %s", self.cam.get("name"), self.error)
            finally:
                self.online, self.fps = False, 0.0
                if cap is not None:
                    cap.release()
            self.stop_evt.wait(backoff)
            backoff = min(backoff * 1.7, 30.0)
