"""Brand presets -> stream URL. Anything not listed works via a custom URL (RTSP/HTTP/file)."""
from __future__ import annotations

from urllib.parse import quote, urlsplit, urlunsplit

# Templates use: {auth} {host} {port} {ch} {ch2}.  "sub" is the low-res stream.
BRANDS: dict[str, dict] = {
    "generic": {"label": "Generic RTSP / HTTP URL (any brand)", "fields": ["url"]},
    "onvif": {"label": "ONVIF (auto-discover stream)", "fields": ["host", "port", "auth", "stream"], "port": 80},
    "hikvision": {"label": "Hikvision", "port": 554,
                  "main": "rtsp://{auth}{host}:{port}/Streaming/Channels/{ch}01",
                  "sub": "rtsp://{auth}{host}:{port}/Streaming/Channels/{ch}02"},
    "dahua": {"label": "Dahua / Amcrest / Lorex", "port": 554,
              "main": "rtsp://{auth}{host}:{port}/cam/realmonitor?channel={ch}&subtype=0",
              "sub": "rtsp://{auth}{host}:{port}/cam/realmonitor?channel={ch}&subtype=1"},
    "axis": {"label": "Axis", "port": 554,
             "main": "rtsp://{auth}{host}:{port}/axis-media/media.amp",
             "sub": "rtsp://{auth}{host}:{port}/axis-media/media.amp?resolution=640x360"},
    "uniview": {"label": "Uniview (UNV)", "port": 554,
                "main": "rtsp://{auth}{host}:{port}/unicast/c{ch}/s0/live",
                "sub": "rtsp://{auth}{host}:{port}/unicast/c{ch}/s1/live"},
    "hanwha": {"label": "Hanwha / Samsung Wisenet", "port": 554,
               "main": "rtsp://{auth}{host}:{port}/profile2/media.smp",
               "sub": "rtsp://{auth}{host}:{port}/profile3/media.smp"},
    "bosch": {"label": "Bosch", "port": 554,
              "main": "rtsp://{auth}{host}:{port}/rtsp_tunnel",
              "sub": "rtsp://{auth}{host}:{port}/rtsp_tunnel?inst=2"},
    "vivotek": {"label": "Vivotek", "port": 554,
                "main": "rtsp://{auth}{host}:{port}/live.sdp",
                "sub": "rtsp://{auth}{host}:{port}/live2.sdp"},
    "reolink": {"label": "Reolink", "port": 554,
                "main": "rtsp://{auth}{host}:{port}/h264Preview_{ch2}_main",
                "sub": "rtsp://{auth}{host}:{port}/h264Preview_{ch2}_sub"},
    "tapo": {"label": "TP-Link Tapo / VIGI", "port": 554,
             "main": "rtsp://{auth}{host}:{port}/stream1",
             "sub": "rtsp://{auth}{host}:{port}/stream2"},
    "foscam": {"label": "Foscam", "port": 554,
               "main": "rtsp://{auth}{host}:{port}/videoMain",
               "sub": "rtsp://{auth}{host}:{port}/videoSub"},
    "usb": {"label": "USB / local webcam", "fields": ["host"]},
    "file": {"label": "Video file (testing)", "fields": ["url"]},
}

for _id, _b in BRANDS.items():
    _b.setdefault("fields", ["host", "port", "auth", "channel", "stream"])
    _b.setdefault("port", 0)


def brand_list() -> list[dict]:
    return [{"id": k, "label": v["label"], "fields": v["fields"], "port": v["port"]}
            for k, v in BRANDS.items()]


def _auth(cam: dict) -> str:
    u = cam.get("username") or ""
    if not u:
        return ""
    return f"{quote(u, safe='')}:{quote(cam.get('password') or '', safe='')}@"


def inject_auth(url: str, cam: dict) -> str:
    """Add credentials to a URL that has none (used for ONVIF-reported URIs)."""
    a = _auth(cam)
    parts = urlsplit(url)
    if not a or "@" in parts.netloc:
        return url
    return urlunsplit((parts.scheme, a + parts.netloc, parts.path, parts.query, parts.fragment))


def build_url(cam: dict) -> str | int:
    """Return what cv2.VideoCapture / ffmpeg should open (int for USB index)."""
    brand = cam.get("brand") or "generic"
    if brand == "usb":
        return int(cam.get("host") or 0)
    if cam.get("url"):
        return cam["url"]
    b = BRANDS.get(brand)
    if not b or "main" not in b:
        raise ValueError(f"No stream URL for brand '{brand}'; provide a custom URL")
    ch = int(cam.get("channel") or 1)
    tpl = b["sub"] if cam.get("stream") == "sub" else b["main"]
    port = int(cam.get("port") or b["port"] or 554)
    return tpl.format(auth=_auth(cam), host=cam.get("host", ""), port=port, ch=ch, ch2=f"{ch:02d}")


def onvif_stream_uri(cam: dict) -> str:
    """Ask an ONVIF device for its RTSP URI (needs the optional `onvif-zeep` package)."""
    try:
        from onvif import ONVIFCamera  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise RuntimeError("Install 'onvif-zeep' to use the ONVIF brand") from e
    dev = ONVIFCamera(cam["host"], int(cam.get("port") or 80), cam.get("username", ""), cam.get("password", ""))
    media = dev.create_media_service()
    profiles = media.GetProfiles()
    prof = profiles[-1] if cam.get("stream") == "sub" and len(profiles) > 1 else profiles[0]
    req = media.create_type("GetStreamUri")
    req.ProfileToken = prof.token
    req.StreamSetup = {"Stream": "RTP-Unicast", "Transport": {"Protocol": "RTSP"}}
    return inject_auth(media.GetStreamUri(req).Uri, cam)


def resolve_url(cam: dict) -> str | int:
    if cam.get("brand") == "onvif" and not cam.get("url"):
        return onvif_stream_uri(cam)
    return build_url(cam)
