"""Runtime settings, read from environment variables (see README)."""
from __future__ import annotations

import os
import secrets
from functools import lru_cache
from pathlib import Path


def _str(name: str, default: str) -> str:
    v = os.environ.get(name)
    return default if v is None or v == "" else v


def _num(name: str, default, cast=float):
    try:
        return cast(os.environ[name])
    except (KeyError, ValueError):
        return default


def _bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    return default if v is None or v == "" else v.strip().lower() in ("1", "true", "yes", "on")


class Settings:
    def __init__(self) -> None:
        self.brand = _str("VMS_BRAND", "McArdle AI VMS")
        self.data_dir = Path(_str("VMS_DATA_DIR", "./data")).resolve()
        self.admin_user = _str("VMS_ADMIN_USER", "admin")
        self.admin_password = _str("VMS_ADMIN_PASSWORD", "admin")
        self.token_ttl = _num("VMS_TOKEN_TTL_HOURS", 12.0) * 3600

        # analytics
        self.model = _str("VMS_MODEL", "yolov8n.pt")
        self.device = _str("VMS_DEVICE", "")            # "", "cpu", "cuda:0"
        self.conf = _num("VMS_CONF", 0.35)
        self.imgsz = _num("VMS_IMGSZ", 640, int)
        self.analytics_fps = _num("VMS_ANALYTICS_FPS", 5.0)
        self.plate_regex = _str("VMS_PLATE_REGEX", "")  # optional strict format filter

        # live view
        self.stream_fps = _num("VMS_STREAM_FPS", 12.0)
        self.stream_quality = _num("VMS_STREAM_QUALITY", 70, int)

        # recording
        self.record = _bool("VMS_RECORD", True)
        self.segment_seconds = _num("VMS_SEGMENT_SECONDS", 300, int)
        self.retention_days = _num("VMS_RETENTION_DAYS", 7.0)

        self.snapshots_dir = self.data_dir / "snapshots"
        self.recordings_dir = self.data_dir / "recordings"
        for d in (self.data_dir, self.snapshots_dir, self.recordings_dir):
            d.mkdir(parents=True, exist_ok=True)
        self.secret = self._load_secret()

    def _load_secret(self) -> str:
        env = os.environ.get("VMS_SECRET")
        if env:
            return env
        p = self.data_dir / "secret.key"
        if p.exists():
            return p.read_text().strip()
        s = secrets.token_hex(32)
        p.write_text(s)
        try:
            p.chmod(0o600)
        except OSError:
            pass
        return s


@lru_cache
def get_settings() -> Settings:
    return Settings()
