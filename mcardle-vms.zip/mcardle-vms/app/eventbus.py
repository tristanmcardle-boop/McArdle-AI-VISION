"""Thread-safe fan-out of events to websocket subscribers."""
from __future__ import annotations

import asyncio


class EventBus:
    def __init__(self) -> None:
        self.loop: asyncio.AbstractEventLoop | None = None
        self.subs: set[asyncio.Queue] = set()

    def bind(self, loop: asyncio.AbstractEventLoop) -> None:
        self.loop = loop

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=200)
        self.subs.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self.subs.discard(q)

    @staticmethod
    def _put(q: asyncio.Queue, ev: dict) -> None:
        try:
            q.put_nowait(ev)
        except asyncio.QueueFull:
            pass

    def publish(self, ev: dict) -> None:
        """Called from worker threads."""
        if not self.loop:
            return
        for q in list(self.subs):
            self.loop.call_soon_threadsafe(self._put, q, ev)
