"""Continuous recording: one `ffmpeg -c copy` segmenter per camera (no re-encoding, very low CPU)."""
from __future__ import annotations

import logging
import re
import shutil
import subprocess
import threading
import time
from datetime import datetime

from .camera.brands import resolve_url

log = logging.getLogger("vms.recorder")
SEG_RE = re.compile(r"^(\d{8}_\d{6})\.mp4$")


class Recorder:
    def __init__(self, settings, db) -> None:
        self.settings, self.db = settings, db
        self.ffmpeg = shutil.which("ffmpeg")
        self.procs: dict[int, subprocess.Popen] = {}
        self.retry_at: dict[int, float] = {}
        self._stop = threading.Event()

    @property
    def enabled(self) -> bool:
        return bool(self.settings.record and self.ffmpeg)

    def start(self) -> None:
        if not self.settings.record:
            log.info("recording disabled (VMS_RECORD=0)")
        elif not self.ffmpeg:
            log.warning("ffmpeg not found - recording disabled")
        else:
            threading.Thread(target=self._loop, daemon=True, name="recorder").start()

    def stop(self) -> None:
        self._stop.set()
        for cid in list(self.procs):
            self._kill(cid)

    def _kill(self, cid: int) -> None:
        p = self.procs.pop(cid, None)
        if p and p.poll() is None:
            p.terminate()
            try:
                p.wait(5)
            except subprocess.TimeoutExpired:
                p.kill()

    def _spawn(self, cam: dict) -> None:
        url = resolve_url(cam)
        if not (isinstance(url, str) and url.lower().startswith(("rtsp://", "rtsps://"))):
            return  # only RTSP sources are recorded
        d = self.settings.recordings_dir / f"cam_{cam['id']}"
        d.mkdir(parents=True, exist_ok=True)
        cmd = [self.ffmpeg, "-hide_banner", "-loglevel", "error", "-rtsp_transport", "tcp", "-i", url,
               "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy",
               "-f", "segment", "-segment_time", str(self.settings.segment_seconds),
               "-segment_atclocktime", "1", "-reset_timestamps", "1", "-strftime", "1",
               "-segment_format", "mp4", "-segment_format_options", "movflags=frag_keyframe+empty_moov",
               str(d / "%Y%m%d_%H%M%S.mp4")]
        self.procs[cam["id"]] = subprocess.Popen(cmd, stdin=subprocess.DEVNULL,
                                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def _loop(self) -> None:
        last_clean = 0.0
        while not self._stop.is_set():
            try:
                want = {c["id"]: c for c in self.db.cameras() if c["enabled"] and c["record"]}
                for cid in list(self.procs):
                    if cid not in want:
                        self._kill(cid)
                for cid, cam in want.items():
                    p = self.procs.get(cid)
                    if (p is None or p.poll() is not None) and time.time() >= self.retry_at.get(cid, 0):
                        self.procs.pop(cid, None)
                        self.retry_at[cid] = time.time() + 15
                        try:
                            self._spawn(cam)
                        except Exception as e:  # noqa: BLE001
                            log.warning("record %s: %s", cam["name"], e)
                if time.time() - last_clean > 3600:
                    last_clean = time.time()
                    self.cleanup()
            except Exception:  # noqa: BLE001
                log.exception("recorder loop")
            self._stop.wait(5)

    def restart_camera(self, cid: int) -> None:
        self._kill(cid)
        self.retry_at.pop(cid, None)

    def cleanup(self) -> None:
        cutoff = time.time() - self.settings.retention_days * 86400
        for f in self.settings.recordings_dir.glob("cam_*/*.mp4"):
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink()
            except OSError:
                pass

    def segments(self, cam_id: int, from_ts: float, to_ts: float) -> list[dict]:
        out = []
        for f in sorted((self.settings.recordings_dir / f"cam_{cam_id}").glob("*.mp4")):
            m = SEG_RE.match(f.name)
            if not m:
                continue
            try:
                start = datetime.strptime(m.group(1), "%Y%m%d_%H%M%S").timestamp()
                st = f.stat()
            except (ValueError, OSError):
                continue
            end = max(st.st_mtime, start)
            if end >= from_ts and start <= to_ts:
                out.append({"name": f.name, "start": start, "end": end, "size": st.st_size})
        return out

    def disk_bytes(self) -> int:
        return sum(f.stat().st_size for f in self.settings.recordings_dir.glob("cam_*/*.mp4"))
