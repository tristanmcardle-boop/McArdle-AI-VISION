"""Tiny stateless HMAC tokens (no external deps)."""
from __future__ import annotations

import base64
import hashlib
import hmac
import time


def _sig(secret: str, msg: str) -> str:
    return hmac.new(secret.encode(), msg.encode(), hashlib.sha256).hexdigest()


def make_token(secret: str, user: str, ttl: float) -> str:
    body = f"{user}|{int(time.time() + ttl)}"
    raw = base64.urlsafe_b64encode(body.encode()).decode().rstrip("=")
    return f"{raw}.{_sig(secret, raw)}"


def verify_token(secret: str, token: str) -> str | None:
    try:
        raw, sig = token.rsplit(".", 1)
        if not hmac.compare_digest(sig, _sig(secret, raw)):
            return None
        body = base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)).decode()
        user, exp = body.rsplit("|", 1)
        return user if int(exp) >= time.time() else None
    except Exception:
        return None


def same(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode(), b.encode())
