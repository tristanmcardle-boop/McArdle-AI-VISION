"""Per-camera analytics workers + the manager that owns them."""
from __future__ import annotations

import logging
import threading
import time
import uuid
from datetime import datetime

import cv2

from .analytics.lpr import PlateReader
from .analytics.render import draw_overlay
from .analytics.rules import build_rule
from .analytics.tracker import IoUTracker
from .camera.source import CameraSource

log = logging.getLogger("vms.engine")


def _resize(img, max_w: int):
    h, w = img.shape[:2]
    if max_w and w > max_w:
        return cv2.resize(img, (max_w, int(h * max_w / w)), interpolation=cv2.INTER_AREA)
    return img


class CameraWorker(threading.Thread):
    def __init__(self, engine: "Engine", cam: dict) -> None:
        super().__init__(daemon=True, name=f"worker-{cam['id']}")
        self.engine, self.cam = engine, cam
        self.settings = engine.settings
        self.plates = engine.plates
        self.source = CameraSource(cam)
        self.tracker = IoUTracker()
        self.rules: list = []
        self.stop_evt = threading.Event()
        self.frame = None
        self.size = (1, 1)
        self.last_tracks: list = []
        self._last_fid = -1
        self._cur_tracks: list = []
        self.reload_rules()

    # -- control -------------------------------------------------------------
    def reload_rules(self) -> None:
        rows = [r for r in self.engine.db.rules(self.cam["id"]) if r["enabled"]]
        self.rules = [r for r in (build_rule(row) for row in rows) if r]

    def stop(self) -> None:
        self.stop_evt.set()
        self.source.stop()

    def status(self) -> dict:
        s = self.source
        return {"online": s.online, "fps": round(s.fps, 1), "error": s.error,
                "resolution": f"{s.size[0]}x{s.size[1]}" if s.size[0] else ""}

    # -- rendering -------------------------------------------------------------
    def render(self, frame, overlay: bool = True, highlight=None):
        """Return frame (read-only) or a copy with the analytics overlay drawn."""
        if not overlay or not (self.last_tracks or self.rules):
            return frame
        return draw_overlay(frame.copy(), self.last_tracks, self.rules, highlight)

    # -- events ----------------------------------------------------------------
    def emit(self, rule, type_, track=None, label=None, direction=None, plate=None, conf=None) -> None:
        ts = time.time()
        snap = None
        try:
            if self.frame is not None:
                if track is not None:  # include the current track in the snapshot
                    self.last_tracks = self._track_view(self._cur_tracks)
                img = self.render(self.frame, True, track.id if track else None)
                snap = self.engine.save_snapshot(img, ts, self.cam["id"])
        except Exception as e:  # noqa: BLE001
            log.warning("snapshot failed: %s", e)
        ev = {"ts": ts, "camera_id": self.cam["id"], "rule_id": rule.id, "rule_name": rule.name,
              "type": type_, "label": label, "direction": direction, "plate": plate,
              "confidence": round(conf, 3) if conf is not None else (round(track.conf, 3) if track else None),
              "snapshot": snap}
        ev["id"] = self.engine.db.event_add(ev)
        ev["camera_name"] = self.cam["name"]
        self.engine.bus.publish(ev)

    @staticmethod
    def _track_view(tracks):
        return [(t.id, t.bbox, t.label, t.conf, t.state.get("plate")) for t in tracks]

    # -- main loop -------------------------------------------------------------
    def run(self) -> None:
        self.source.start()
        period = 1.0 / max(0.5, self.settings.analytics_fps)
        while not self.stop_evt.is_set():
            t0 = time.time()
            try:
                fid, frame = self.source.get()
                if frame is None or fid == self._last_fid:
                    time.sleep(0.03)
                    continue
                self._last_fid = fid
                if not (self.cam.get("analytics") and self.rules):
                    self.last_tracks = []
                    time.sleep(0.25)
                    continue
                self.frame, self.size = frame, (frame.shape[1], frame.shape[0])
                self._cur_tracks = self.tracker.update(self.engine.detector.detect(frame), t0)
                for r in self.rules:
                    try:
                        r.process(self._cur_tracks, t0, self)
                    except Exception:  # noqa: BLE001
                        log.exception("rule %s failed", r.name)
                self.last_tracks = self._track_view(self._cur_tracks)
            except Exception:  # noqa: BLE001
                log.exception("worker %s loop error", self.cam.get("name"))
                time.sleep(1)
            self.stop_evt.wait(max(0.0, period - (time.time() - t0)))


class Engine:
    def __init__(self, settings, db, bus, detector) -> None:
        self.settings, self.db, self.bus, self.detector = settings, db, bus, detector
        self.plates = PlateReader(settings)
        self.workers: dict[int, CameraWorker] = {}
        self._lock = threading.Lock()
        self._stop = threading.Event()

    def start(self) -> None:
        for cam in self.db.cameras():
            if cam["enabled"]:
                self.start_camera(cam)
        threading.Thread(target=self._housekeeping, daemon=True, name="housekeeping").start()

    def stop(self) -> None:
        self._stop.set()
        for cid in list(self.workers):
            self.stop_camera(cid)

    def start_camera(self, cam: dict) -> None:
        self.stop_camera(cam["id"])
        w = CameraWorker(self, cam)
        with self._lock:
            self.workers[cam["id"]] = w
        w.start()

    def stop_camera(self, cid: int) -> None:
        with self._lock:
            w = self.workers.pop(cid, None)
        if w:
            w.stop()

    def get(self, cid: int) -> CameraWorker | None:
        return self.workers.get(cid)

    def reload_rules(self, cid: int) -> None:
        w = self.get(cid)
        if w:
            w.reload_rules()

    def save_snapshot(self, img, ts: float, cam_id: int) -> str:
        day = datetime.fromtimestamp(ts).strftime("%Y%m%d")
        rel = f"{day}/{int(ts * 1000)}_{cam_id}_{uuid.uuid4().hex[:4]}.jpg"
        path = self.settings.snapshots_dir / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        cv2.imwrite(str(path), _resize(img, 960), [cv2.IMWRITE_JPEG_QUALITY, 80])
        return rel

    def _housekeeping(self) -> None:
        while not self._stop.wait(3600):
            try:
                cutoff = time.time() - self.settings.retention_days * 86400
                for rel in self.db.purge_events(cutoff):
                    (self.settings.snapshots_dir / rel).unlink(missing_ok=True)
            except Exception:  # noqa: BLE001
                log.exception("housekeeping failed")
