"""Licence-plate recognition. Backends (first available wins):
   1. fast-alpr  (ONNX plate detector + OCR)   pip install fast-alpr[onnx]
   2. EasyOCR    (generic OCR on the vehicle crop)   pip install easyocr
"""
from __future__ import annotations

import logging
import re
import threading

log = logging.getLogger("vms.lpr")


def normalize_plate(text: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", (text or "").upper())


def plausible(plate: str, regex: str = "") -> bool:
    if not (4 <= len(plate) <= 10) or not any(c.isdigit() for c in plate):
        return False
    return bool(re.fullmatch(regex, plate)) if regex else True


def _mean(v) -> float:
    if isinstance(v, (list, tuple)):
        return float(sum(v) / len(v)) if v else 0.0
    return float(v or 0.0)


class PlateReader:
    """read(image_bgr) -> [(plate_text, confidence 0-1, (x1,y1,x2,y2))]"""

    def __init__(self, settings) -> None:
        self.settings = settings
        self.backend = ""
        self.error = ""
        self._loaded = False
        self._impl = None
        self._lock = threading.Lock()

    def _load(self) -> None:
        self._loaded = True
        try:
            from fast_alpr import ALPR  # type: ignore

            self._impl, self.backend = ALPR(), "fast-alpr"
            return
        except Exception as e:  # noqa: BLE001
            self.error = f"fast-alpr: {str(e)[:120]}"
        try:
            import easyocr  # type: ignore

            self._impl, self.backend = easyocr.Reader(["en"], gpu=False, verbose=False), "easyocr"
            self.error = ""
        except Exception as e:  # noqa: BLE001
            self.error += f" | easyocr: {str(e)[:120]}"
            log.error("no LPR backend available (%s)", self.error)

    def status(self) -> dict:
        return {"loaded": self._loaded, "backend": self.backend, "error": self.error}

    def read(self, img) -> list[tuple[str, float, tuple[int, int, int, int]]]:
        with self._lock:
            if not self._loaded:
                self._load()
            if self._impl is None:
                return []
            try:
                return self._read_fast(img) if self.backend == "fast-alpr" else self._read_easy(img)
            except Exception as e:  # noqa: BLE001
                log.warning("LPR read failed: %s", e)
                return []

    def _read_fast(self, img):
        out = []
        for r in self._impl.predict(img):
            if r.ocr is None or not r.ocr.text:
                continue
            bb = r.detection.bounding_box
            conf = min(float(r.detection.confidence), _mean(r.ocr.confidence)) if r.ocr.confidence else float(r.detection.confidence)
            out.append((normalize_plate(r.ocr.text), conf, (int(bb.x1), int(bb.y1), int(bb.x2), int(bb.y2))))
        return out

    def _read_easy(self, img):
        h, w = img.shape[:2]
        out = []
        for pts, text, conf in self._impl.readtext(img, allowlist="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 "):
            xs, ys = [p[0] for p in pts], [p[1] for p in pts]
            out.append((normalize_plate(text), float(conf),
                        (int(min(xs)), int(min(ys)), int(max(xs)), int(max(ys)))))
        return [o for o in out if o[0]]
