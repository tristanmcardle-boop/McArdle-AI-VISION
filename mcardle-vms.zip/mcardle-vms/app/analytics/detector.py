"""Object detector wrapper (Ultralytics YOLO). Degrades gracefully if the model can't load."""
from __future__ import annotations

import logging
import threading

from .types import Detection

log = logging.getLogger("vms.detector")
ALLOWED = {"person", "bicycle", "car", "motorcycle", "bus", "truck"}


class Detector:
    """One shared model instance; calls from all camera workers are serialised."""

    def __init__(self, settings) -> None:
        self.settings = settings
        self.lock = threading.Lock()
        self.model = None
        self.error = ""
        try:
            from ultralytics import YOLO  # heavy import, keep lazy

            self.model = YOLO(settings.model)
            log.info("detector loaded: %s", settings.model)
        except Exception as e:  # noqa: BLE001
            self.error = str(e)[:300]
            log.error("detector unavailable (%s) - analytics will not detect objects", self.error)

    @property
    def ready(self) -> bool:
        return self.model is not None

    def detect(self, frame) -> list[Detection]:
        if self.model is None:
            return []
        s = self.settings
        with self.lock:
            res = self.model.predict(frame, imgsz=s.imgsz, conf=s.conf, device=s.device or None,
                                     verbose=False)[0]
        names, out = res.names, []
        for b in res.boxes:
            label = names[int(b.cls[0])]
            if label in ALLOWED:
                x1, y1, x2, y2 = (float(v) for v in b.xyxy[0].tolist())
                out.append(Detection((x1, y1, x2, y2), label, float(b.conf[0])))
        return out
