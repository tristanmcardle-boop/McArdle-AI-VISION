"""Lightweight multi-object tracker: greedy IoU matching with constant-velocity prediction."""
from __future__ import annotations

from collections import defaultdict

from .geometry import iou
from .types import Detection


class Track:
    def __init__(self, tid: int, det: Detection, ts: float) -> None:
        self.id = tid
        self.bbox = det.bbox
        self.vel = (0.0, 0.0, 0.0, 0.0)
        self.votes: dict[str, float] = defaultdict(float)
        self.votes[det.label] += det.conf
        self.label = det.label
        self.conf = det.conf
        self.hits = 1
        self.missed = 0
        self.first_ts = self.last_ts = ts
        self.state: dict = {}  # per-rule scratch space

    def predicted(self):
        return tuple(b + v for b, v in zip(self.bbox, self.vel))

    def update(self, det: Detection, ts: float) -> None:
        nv = tuple(n - o for n, o in zip(det.bbox, self.bbox))
        self.vel = tuple(0.5 * v + 0.5 * n for v, n in zip(self.vel, nv))
        self.bbox, self.conf = det.bbox, det.conf
        self.votes[det.label] += det.conf
        self.label = max(self.votes, key=self.votes.get)
        self.hits += 1
        self.missed = 0
        self.last_ts = ts

    def anchor(self, w: int, h: int, mode: str = "bottom") -> tuple[float, float]:
        x1, y1, x2, y2 = self.bbox
        cy = y2 if mode == "bottom" else (y1 + y2) / 2
        return ((x1 + x2) / 2 / w, cy / h)


def _group(label: str) -> str:
    return "person" if label == "person" else "other"


class IoUTracker:
    def __init__(self, iou_threshold: float = 0.2, max_missed: int = 10, min_hits: int = 2) -> None:
        self.iou_threshold, self.max_missed, self.min_hits = iou_threshold, max_missed, min_hits
        self.tracks: list[Track] = []
        self._next = 1

    def update(self, dets: list[Detection], ts: float) -> list[Track]:
        pairs = []
        for ti, t in enumerate(self.tracks):
            pb = t.predicted()
            for di, d in enumerate(dets):
                if _group(t.label) != _group(d.label):
                    continue
                s = max(iou(pb, d.bbox), iou(t.bbox, d.bbox))
                if s >= self.iou_threshold:
                    pairs.append((s, ti, di))
        pairs.sort(reverse=True)
        used_t, used_d = set(), set()
        for _, ti, di in pairs:
            if ti in used_t or di in used_d:
                continue
            used_t.add(ti)
            used_d.add(di)
            self.tracks[ti].update(dets[di], ts)
        for ti, t in enumerate(self.tracks):
            if ti not in used_t:
                t.missed += 1
        for di, d in enumerate(dets):
            if di not in used_d:
                self.tracks.append(Track(self._next, d, ts))
                self._next += 1
        self.tracks = [t for t in self.tracks if t.missed <= self.max_missed]
        return [t for t in self.tracks if t.missed == 0 and t.hits >= self.min_hits]
