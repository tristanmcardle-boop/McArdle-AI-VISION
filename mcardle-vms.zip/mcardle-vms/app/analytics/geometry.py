"""Pure geometry helpers (all work in normalised 0-1 coordinates)."""
from __future__ import annotations

Point = tuple[float, float]


def side(a: Point, b: Point, p: Point) -> float:
    """Signed area: >0 when p is on the 'positive' side of the directed line a->b."""
    return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])


def line_cross(a: Point, b: Point, p0: Point, p1: Point) -> int:
    """+1 if the path p0->p1 crosses the *finite* segment a-b going negative->positive side,
    -1 for positive->negative, 0 for no crossing."""
    s0, s1 = side(a, b, p0), side(a, b, p1)
    if s0 == 0 or s1 == 0 or (s0 > 0) == (s1 > 0):
        return 0
    u = s0 / (s0 - s1)
    ix, iy = p0[0] + u * (p1[0] - p0[0]), p0[1] + u * (p1[1] - p0[1])
    dx, dy = b[0] - a[0], b[1] - a[1]
    l2 = dx * dx + dy * dy
    if l2 == 0:
        return 0
    t = ((ix - a[0]) * dx + (iy - a[1]) * dy) / l2
    if t < 0 or t > 1:
        return 0
    return 1 if s1 > 0 else -1


def point_in_polygon(p: Point, poly: list[Point]) -> bool:
    if len(poly) < 3:
        return False
    x, y, inside = p[0], p[1], False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi, xj, yj = poly[i][0], poly[i][1], poly[j][0], poly[j][1]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi:
            inside = not inside
        j = i
    return inside


def iou(a, b) -> float:
    ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
    ix2, iy2 = min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    if inter <= 0:
        return 0.0
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0
