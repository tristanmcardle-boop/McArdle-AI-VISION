"""Draws analytics overlays (rules, tracks, counters) onto frames."""
from __future__ import annotations

import cv2
import numpy as np

COLORS = {"person": (120, 200, 80), "car": (255, 160, 60), "truck": (60, 160, 255),
          "bus": (255, 100, 200), "motorcycle": (60, 220, 255), "bicycle": (180, 180, 60)}
LINE_C, ZONE_C, LPR_C = (0, 200, 255), (60, 120, 255), (255, 200, 0)


def _px(p, w, h):
    return int(p[0] * w), int(p[1] * h)


def _label(img, text, org, color, scale):
    (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, 1)
    x, y = org
    cv2.rectangle(img, (x, y - th - 6), (x + tw + 6, y + 2), color, -1)
    cv2.putText(img, text, (x + 3, y - 3), cv2.FONT_HERSHEY_SIMPLEX, scale, (20, 20, 20), 1, cv2.LINE_AA)


def draw_overlay(img, tracks, rules, highlight=None):
    h, w = img.shape[:2]
    s = max(0.4, w / 1600)
    th = max(1, int(round(w / 700)))
    for r in rules:
        if r.kind == "line":
            a, b = _px(r.a, w, h), _px(r.b, w, h)
            cv2.line(img, a, b, LINE_C, th + 1, cv2.LINE_AA)
            mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
            nx, ny = -(b[1] - a[1]), (b[0] - a[0])
            n = max(1.0, (nx * nx + ny * ny) ** 0.5)
            k = r.in_sign * 40 * s / n
            cv2.arrowedLine(img, (int(mx), int(my)), (int(mx + nx * k), int(my + ny * k)), LINE_C, th, tipLength=0.4)
            t = r.totals()
            _label(img, f"{r.name}  IN {t['in']}  OUT {t['out']}", (a[0], max(18, a[1] - 8)), LINE_C, 0.55 * s * 1.6)
        elif r.kind in ("zone", "lpr") and r.poly:
            pts = np.array([_px(p, w, h) for p in r.poly], np.int32)
            col = ZONE_C if r.kind == "zone" else LPR_C
            ov = img.copy()
            cv2.fillPoly(ov, [pts], col)
            cv2.addWeighted(ov, 0.18, img, 0.82, 0, img)
            cv2.polylines(img, [pts], True, col, th, cv2.LINE_AA)
            extra = f"  [{r.occupancy}]" if r.kind == "zone" else "  LPR"
            _label(img, r.name + extra, (int(pts[0][0]), max(18, int(pts[0][1]) - 8)), col, 0.55 * s * 1.6)
    for tid, bbox, label, conf, plate in tracks:
        x1, y1, x2, y2 = (int(v) for v in bbox)
        col = COLORS.get(label, (200, 200, 200))
        cv2.rectangle(img, (x1, y1), (x2, y2), col, th + (1 if tid == highlight else 0))
        _label(img, plate or f"{label} #{tid}", (x1, max(16, y1)), col, 0.5 * s * 1.6)
    return img
