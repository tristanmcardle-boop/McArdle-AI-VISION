from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Detection:
    bbox: tuple[float, float, float, float]  # x1,y1,x2,y2 in pixels
    label: str
    conf: float
