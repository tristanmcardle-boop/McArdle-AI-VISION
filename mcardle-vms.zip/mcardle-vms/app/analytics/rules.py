"""Runtime analytics rules. Each rule is fed tracks once per analytics cycle.

Rule params (all coordinates normalised 0-1):
  line : {points:[[x,y],[x,y]], classes:[...], invert:bool, anchor:"bottom"|"center"}
  zone : {points:[[x,y],...>=3], classes:[...], dwell_seconds:int, anchor:...}
  lpr  : {points:[...]|[], mode:"vehicle"|"frame", min_conf:0-1, cooldown:int}
"""
from __future__ import annotations

from collections import defaultdict

from .detector import ALLOWED
from .geometry import line_cross, point_in_polygon, side
from .lpr import normalize_plate, plausible

VEHICLES = {"car", "truck", "bus", "motorcycle"}


def validate_params(type_: str, p: dict) -> dict:
    """Return a cleaned copy of params or raise ValueError."""
    def pts(key, lo, hi=None):
        raw = p.get(key) or []
        try:
            out = [[min(1.0, max(0.0, float(x))), min(1.0, max(0.0, float(y)))] for x, y in raw]
        except (TypeError, ValueError):
            raise ValueError("points must be [[x,y],...] with values 0-1")
        if len(out) < lo or (hi and len(out) > hi):
            raise ValueError(f"{type_} needs {'exactly ' + str(lo) if hi == lo else 'at least ' + str(lo)} points")
        return out

    classes = [c for c in (p.get("classes") or ["person"]) if c in ALLOWED] or ["person"]
    anchor = "center" if p.get("anchor") == "center" else "bottom"
    if type_ == "line":
        return {"points": pts("points", 2, 2), "classes": classes, "invert": bool(p.get("invert")), "anchor": anchor}
    if type_ == "zone":
        return {"points": pts("points", 3), "classes": classes, "anchor": anchor,
                "dwell_seconds": max(0, int(p.get("dwell_seconds") or 0))}
    if type_ == "lpr":
        return {"points": pts("points", 0), "mode": "frame" if p.get("mode") == "frame" else "vehicle",
                "min_conf": min(1.0, max(0.1, float(p.get("min_conf") or 0.5))),
                "cooldown": max(0, int(p.get("cooldown") or 30))}
    raise ValueError(f"unknown rule type '{type_}'")


class Rule:
    kind = ""

    def __init__(self, row: dict) -> None:
        self.id, self.name, self.params = row["id"], row["name"], row["params"]
        self.poly = [tuple(p) for p in self.params.get("points", [])]

    def process(self, tracks, ts: float, w) -> None:  # w = CameraWorker
        raise NotImplementedError


class LineRule(Rule):
    kind = "line"

    def __init__(self, row):
        super().__init__(row)
        self.a, self.b = self.poly[0], self.poly[1]
        self.classes = set(self.params["classes"])
        self.in_sign = -1 if self.params.get("invert") else 1
        self.anchor = self.params.get("anchor", "bottom")
        self.counts: dict[str, dict[str, int]] = defaultdict(lambda: {"in": 0, "out": 0})

    def process(self, tracks, ts, w):
        W, H = w.size
        for t in tracks:
            if t.label not in self.classes:
                continue
            cur = t.anchor(W, H, self.anchor)
            s = side(self.a, self.b, cur)
            if s == 0:
                continue
            last = t.state.get(("line", self.id))  # (last_pos, last_side)
            if last and (last[1] > 0) != (s > 0):
                res = line_cross(self.a, self.b, last[0], cur)
                if res:
                    direction = "in" if res * self.in_sign > 0 else "out"
                    self.counts[t.label][direction] += 1
                    w.emit(self, "line_cross", track=t, label=t.label, direction=direction)
            t.state[("line", self.id)] = (cur, s)

    def totals(self) -> dict[str, int]:
        return {d: sum(c[d] for c in self.counts.values()) for d in ("in", "out")}


class ZoneRule(Rule):
    kind = "zone"

    def __init__(self, row):
        super().__init__(row)
        self.classes = set(self.params["classes"])
        self.dwell = self.params.get("dwell_seconds", 0)
        self.anchor = self.params.get("anchor", "bottom")
        self.occupancy = 0

    def process(self, tracks, ts, w):
        W, H = w.size
        n = 0
        for t in tracks:
            if t.label not in self.classes:
                continue
            st = t.state.setdefault(("zone", self.id), {"inside": False, "since": 0.0, "dwell": False})
            if point_in_polygon(t.anchor(W, H, self.anchor), self.poly):
                n += 1
                if not st["inside"]:
                    st.update(inside=True, since=ts, dwell=False)
                    w.emit(self, "zone_enter", track=t, label=t.label)
                elif self.dwell and not st["dwell"] and ts - st["since"] >= self.dwell:
                    st["dwell"] = True
                    w.emit(self, "zone_dwell", track=t, label=t.label)
            else:
                st.update(inside=False, dwell=False)
        self.occupancy = n


class LprRule(Rule):
    kind = "lpr"
    INTERVAL, MAX_TRIES = 0.6, 8

    def __init__(self, row):
        super().__init__(row)
        self.mode = self.params.get("mode", "vehicle")
        self.min_conf = self.params.get("min_conf", 0.5)
        self.cooldown = self.params.get("cooldown", 30)
        self.seen: dict[str, float] = {}
        self.last_frame_ts = 0.0

    def _accept(self, text, conf, ts, w, track=None) -> bool:
        plate = normalize_plate(text)
        if conf < self.min_conf or not plausible(plate, w.settings.plate_regex):
            return False
        if ts - self.seen.get(plate, 0.0) >= self.cooldown:
            self.seen[plate] = ts
            if track is not None:
                track.state["plate"] = plate
            w.emit(self, "plate", track=track, label=track.label if track else "vehicle", plate=plate, conf=conf)
        return True

    def process(self, tracks, ts, w):
        frame = w.frame
        H, W = frame.shape[:2]
        if self.mode == "frame":
            if ts - self.last_frame_ts < 0.5:
                return
            self.last_frame_ts = ts
            for text, conf, (x1, y1, x2, y2) in w.plates.read(frame):
                c = ((x1 + x2) / 2 / W, (y1 + y2) / 2 / H)
                if not self.poly or point_in_polygon(c, self.poly):
                    self._accept(text, conf, ts, w)
            return
        for t in tracks:
            if t.label not in VEHICLES:
                continue
            st = t.state.setdefault(("lpr", self.id), {"tries": 0, "last": 0.0, "done": False})
            if st["done"] or st["tries"] >= self.MAX_TRIES or ts - st["last"] < self.INTERVAL:
                continue
            if self.poly and not point_in_polygon(t.anchor(W, H), self.poly):
                continue
            x1, y1, x2, y2 = t.bbox
            pw, ph = (x2 - x1) * 0.05, (y2 - y1) * 0.05
            x1, y1 = max(0, int(x1 - pw)), max(0, int(y1 - ph))
            x2, y2 = min(W, int(x2 + pw)), min(H, int(y2 + ph))
            if x2 - x1 < 60 or y2 - y1 < 40:
                continue
            st["last"] = ts
            st["tries"] += 1
            reads = w.plates.read(frame[y1:y2, x1:x2])
            if reads:
                text, conf, _ = max(reads, key=lambda r: r[1])
                st["done"] = self._accept(text, conf, ts, w, track=t)


def build_rule(row: dict) -> Rule | None:
    cls = {"line": LineRule, "zone": ZoneRule, "lpr": LprRule}.get(row["type"])
    try:
        return cls(row) if cls else None
    except Exception:  # noqa: BLE001 - a malformed stored rule must not kill the worker
        return None


__all__ = ["validate_params", "build_rule", "LineRule", "ZoneRule", "LprRule"]
