"""FastAPI application: REST API, MJPEG live streams, websocket events and the web UI.

Run:  uvicorn app.main:create_app --factory --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import asyncio
import csv
import io
import logging
import re
import shutil
import time
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Literal

import anyio.to_thread
import cv2
import numpy as np
from fastapi import APIRouter, Depends, FastAPI, Header, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import __version__
from .analytics.detector import ALLOWED, Detector
from .analytics.rules import validate_params
from .camera.brands import BRANDS, brand_list, resolve_url
from .camera.discovery import discover
from .camera.source import open_capture
from .config import get_settings
from .db import DB
from .engine import Engine
from .eventbus import EventBus
from .recorder import Recorder
from .security import make_token, same, verify_token

log = logging.getLogger("vms")
STATIC = Path(__file__).parent / "static"


class CameraIn(BaseModel):
    name: str
    brand: str = "generic"
    host: str = ""
    port: int = 0
    username: str = ""
    password: str = ""
    channel: int = 1
    stream: Literal["main", "sub"] = "main"
    url: str = ""
    enabled: bool = True
    record: bool = True
    analytics: bool = True


class RuleIn(BaseModel):
    type: Literal["line", "zone", "lpr"]
    name: str
    params: dict = {}
    enabled: bool = True


class RulePatch(BaseModel):
    name: str | None = None
    params: dict | None = None
    enabled: bool | None = None


class Login(BaseModel):
    username: str
    password: str


def _validate_camera(d: dict) -> None:
    if not d["name"].strip():
        raise HTTPException(422, "Name is required")
    if d["brand"] not in BRANDS:
        raise HTTPException(422, f"Unknown brand '{d['brand']}'")
    fields = BRANDS[d["brand"]]["fields"]
    if "url" in fields and not d["url"].strip():
        raise HTTPException(422, "A stream URL / file path is required for this camera type")
    if "host" in fields and not d["url"].strip() and d["brand"] != "usb" and not d["host"].strip():
        raise HTTPException(422, "Host / IP address is required")


def _placeholder(text: str = "NO SIGNAL") -> bytes:
    img = np.full((360, 640, 3), 28, np.uint8)
    (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 1.0, 2)
    cv2.putText(img, text, ((640 - tw) // 2, (360 + th) // 2), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (150, 150, 150), 2, cv2.LINE_AA)
    return cv2.imencode(".jpg", img)[1].tobytes()


def create_app() -> FastAPI:
    settings = get_settings()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if settings.admin_password == "admin":
        log.warning("Using the default admin password - set VMS_ADMIN_PASSWORD before exposing this server!")
    db = DB(settings.data_dir / "vms.db")
    bus = EventBus()
    detector = Detector(settings)
    engine = Engine(settings, db, bus, detector)
    recorder = Recorder(settings, db)
    no_signal = _placeholder()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        bus.bind(asyncio.get_running_loop())
        anyio.to_thread.current_default_thread_limiter().total_tokens = 256  # one thread per live stream
        engine.start()
        recorder.start()
        yield
        recorder.stop()
        engine.stop()

    app = FastAPI(title=settings.brand, version=__version__, lifespan=lifespan)

    # ---- auth -------------------------------------------------------------
    def require_auth(authorization: str | None = Header(default=None), token: str | None = Query(default=None)) -> str:
        tok = token or (authorization or "").removeprefix("Bearer ").strip()
        user = verify_token(settings.secret, tok) if tok else None
        if not user:
            raise HTTPException(401, "Not authenticated")
        return user

    pub = APIRouter(prefix="/api")
    api = APIRouter(prefix="/api", dependencies=[Depends(require_auth)])

    @pub.get("/config")
    def public_config():
        return {"brand": settings.brand, "version": __version__}

    @pub.post("/login")
    def login(body: Login):
        if same(body.username, settings.admin_user) and same(body.password, settings.admin_password):
            return {"token": make_token(settings.secret, body.username, settings.token_ttl), "user": body.username}
        time.sleep(0.6)  # slow down brute force
        raise HTTPException(401, "Invalid username or password")

    # ---- cameras ----------------------------------------------------------
    def public_cam(c: dict) -> dict:
        w = engine.get(c["id"])
        out = {k: v for k, v in c.items() if k != "password"}
        out.update(has_password=bool(c.get("password")), enabled=bool(c["enabled"]), record=bool(c["record"]),
                   analytics=bool(c["analytics"]), recording=c["id"] in recorder.procs)
        out.update(w.status() if w else {"online": False, "fps": 0, "error": "stopped", "resolution": ""})
        return out

    @api.get("/brands")
    def brands():
        return brand_list()

    @api.get("/discover")
    def discover_cameras():
        return discover(3.0)

    @api.get("/cameras")
    def list_cameras():
        return [public_cam(c) for c in db.cameras()]

    @api.post("/cameras", status_code=201)
    def create_camera(body: CameraIn):
        d = body.model_dump()
        _validate_camera(d)
        cid = db.camera_create(d)
        cam = db.camera(cid)
        if cam["enabled"]:
            engine.start_camera(cam)
        return public_cam(cam)

    @api.put("/cameras/{cid}")
    def update_camera(cid: int, body: CameraIn):
        if not db.camera(cid):
            raise HTTPException(404, "Camera not found")
        d = body.model_dump()
        _validate_camera(d)
        if not d["password"]:
            d.pop("password")  # blank = keep the stored password
        db.camera_update(cid, d)
        cam = db.camera(cid)
        recorder.restart_camera(cid)
        engine.stop_camera(cid)
        if cam["enabled"]:
            engine.start_camera(cam)
        return public_cam(cam)

    @api.delete("/cameras/{cid}", status_code=204)
    def delete_camera(cid: int):
        engine.stop_camera(cid)
        recorder.restart_camera(cid)
        db.camera_delete(cid)
        return Response(status_code=204)

    @api.post("/cameras/test")
    def test_camera(body: CameraIn):
        d = body.model_dump()
        if not d["password"] and body.host:  # editing: reuse a stored password for the same host
            for c in db.cameras():
                if c["host"] == body.host and c["username"] == body.username:
                    d["password"] = c["password"]
        try:
            _validate_camera(d)
            cap = open_capture(resolve_url(d))
            try:
                ok, frame = cap.read() if cap.isOpened() else (False, None)
            finally:
                cap.release()
            if not ok or frame is None:
                return {"ok": False, "error": "Could not read a frame - check address, credentials and brand."}
            return {"ok": True, "width": int(frame.shape[1]), "height": int(frame.shape[0])}
        except HTTPException as e:
            return {"ok": False, "error": e.detail}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)[:200]}

    @api.get("/cameras/{cid}/snapshot")
    def snapshot(cid: int, overlay: int = 1):
        w = engine.get(cid)
        if not w:
            raise HTTPException(404, "Camera not running")
        _, frame = w.source.get()
        data = no_signal if frame is None else cv2.imencode(".jpg", w.render(frame, bool(overlay)))[1].tobytes()
        return Response(data, media_type="image/jpeg", headers={"Cache-Control": "no-store"})

    @api.get("/cameras/{cid}/stream")
    def stream(cid: int, overlay: int = 1, width: int = 0):
        w = engine.get(cid)
        if not w:
            raise HTTPException(404, "Camera not running")
        period = 1.0 / max(1.0, settings.stream_fps)
        params = [cv2.IMWRITE_JPEG_QUALITY, settings.stream_quality]

        def gen():
            last, idle = -1, 0.0
            while engine.get(cid) is w:
                t0 = time.time()
                fid, frame = w.source.get()
                if frame is None:
                    if time.time() - idle > 1.0:
                        idle, jpg = time.time(), no_signal
                    else:
                        time.sleep(0.1)
                        continue
                elif fid == last:
                    time.sleep(0.02)
                    continue
                else:
                    last = fid
                    img = w.render(frame, bool(overlay))
                    if width and img.shape[1] > width:
                        img = cv2.resize(img, (width, int(img.shape[0] * width / img.shape[1])), interpolation=cv2.INTER_AREA)
                    jpg = cv2.imencode(".jpg", img, params)[1].tobytes()
                yield b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: %d\r\n\r\n%s\r\n" % (len(jpg), jpg)
                time.sleep(max(0.0, period - (time.time() - t0)))

        return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame",
                                 headers={"Cache-Control": "no-store"})

    # ---- rules ------------------------------------------------------------
    @api.get("/cameras/{cid}/rules")
    def camera_rules(cid: int):
        return db.rules(cid)

    @api.post("/cameras/{cid}/rules", status_code=201)
    def create_rule(cid: int, body: RuleIn):
        if not db.camera(cid):
            raise HTTPException(404, "Camera not found")
        try:
            params = validate_params(body.type, body.params)
        except ValueError as e:
            raise HTTPException(422, str(e))
        rid = db.rule_create(cid, body.type, body.name.strip() or body.type, params, body.enabled)
        engine.reload_rules(cid)
        return db.rule(rid)

    @api.patch("/rules/{rid}")
    def patch_rule(rid: int, body: RulePatch):
        rule = db.rule(rid)
        if not rule:
            raise HTTPException(404, "Rule not found")
        params = None
        if body.params is not None:
            try:
                params = validate_params(rule["type"], body.params)
            except ValueError as e:
                raise HTTPException(422, str(e))
        db.rule_update(rid, body.name, params, body.enabled)
        engine.reload_rules(rule["camera_id"])
        return db.rule(rid)

    @api.delete("/rules/{rid}", status_code=204)
    def delete_rule(rid: int):
        rule = db.rule(rid)
        if rule:
            db.rule_delete(rid)
            engine.reload_rules(rule["camera_id"])
        return Response(status_code=204)

    # ---- events & stats ---------------------------------------------------
    @api.get("/events")
    def list_events(camera_id: int | None = None, type: str | None = None, plate: str | None = None,
                    from_ts: float | None = None, to_ts: float | None = None,
                    before_id: int | None = None, limit: int = 100):
        return db.events(camera_id, type, plate, from_ts, to_ts, before_id, limit)

    @api.get("/events/export.csv")
    def export_events(camera_id: int | None = None, type: str | None = None,
                      from_ts: float | None = None, to_ts: float | None = None):
        names = {c["id"]: c["name"] for c in db.cameras()}
        buf = io.StringIO()
        wr = csv.writer(buf)
        wr.writerow(["id", "time", "camera", "type", "rule", "label", "direction", "plate", "confidence"])
        before = None
        for _ in range(20):  # up to 20k rows
            rows = db.events(camera_id, type, None, from_ts, to_ts, before, 1000)
            for e in rows:
                wr.writerow([e["id"], datetime.fromtimestamp(e["ts"]).isoformat(sep=" ", timespec="seconds"),
                             names.get(e["camera_id"], e["camera_id"]), e["type"], e["rule_name"], e["label"],
                             e["direction"], e["plate"], e["confidence"]])
            if len(rows) < 1000:
                break
            before = rows[-1]["id"]
        return Response(buf.getvalue(), media_type="text/csv",
                        headers={"Content-Disposition": "attachment; filename=events.csv"})

    @api.get("/events/{eid}/snapshot")
    def event_snapshot(eid: int):
        e = db.event(eid)
        if not e or not e["snapshot"]:
            raise HTTPException(404, "No snapshot")
        path = (settings.snapshots_dir / e["snapshot"]).resolve()
        if not path.is_relative_to(settings.snapshots_dir) or not path.exists():
            raise HTTPException(404, "Snapshot missing")
        return FileResponse(path, media_type="image/jpeg")

    @api.get("/stats/counts")
    def stats_counts(camera_id: int | None = None, from_ts: float | None = None,
                     to_ts: float | None = None, bucket: int = 3600):
        now = time.time()
        start = from_ts if from_ts is not None else datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        return {"from_ts": start, "bucket": bucket,
                "rows": db.counts(camera_id, start, to_ts if to_ts is not None else now, max(60, bucket))}

    # ---- recordings -------------------------------------------------------
    @api.get("/cameras/{cid}/recordings")
    def recordings(cid: int, from_ts: float, to_ts: float):
        return recorder.segments(cid, from_ts, to_ts)

    @api.get("/recordings/{cid}/{name}")
    def recording_file(cid: int, name: str):
        if not re.fullmatch(r"\d{8}_\d{6}\.mp4", name):
            raise HTTPException(400, "Bad file name")
        path = settings.recordings_dir / f"cam_{cid}" / name
        if not path.exists():
            raise HTTPException(404, "Recording not found")
        return FileResponse(path, media_type="video/mp4")

    # ---- system -----------------------------------------------------------
    @api.get("/system")
    def system():
        du = shutil.disk_usage(settings.data_dir)
        cams = [public_cam(c) for c in db.cameras()]
        return {
            "version": __version__, "brand": settings.brand,
            "cameras": {"total": len(cams), "online": sum(1 for c in cams if c["online"])},
            "detector": {"ready": detector.ready, "model": settings.model, "error": detector.error,
                         "device": settings.device or "auto", "classes": sorted(ALLOWED)},
            "lpr": engine.plates.status(),
            "recording": {"enabled": recorder.enabled, "ffmpeg": bool(recorder.ffmpeg),
                          "segment_seconds": settings.segment_seconds, "retention_days": settings.retention_days,
                          "used_bytes": recorder.disk_bytes()},
            "disk": {"total": du.total, "free": du.free},
            "analytics_fps": settings.analytics_fps,
        }

    app.include_router(pub)
    app.include_router(api)

    # ---- websocket --------------------------------------------------------
    @app.websocket("/ws/events")
    async def ws_events(ws: WebSocket, token: str = ""):
        if not verify_token(settings.secret, token):
            await ws.close(code=4401)
            return
        await ws.accept()
        q = bus.subscribe()
        recv = asyncio.create_task(ws.receive_text())
        try:
            while True:
                getter = asyncio.create_task(q.get())
                done, _ = await asyncio.wait({recv, getter}, return_when=asyncio.FIRST_COMPLETED)
                if recv in done:
                    getter.cancel()
                    recv.result()  # raises WebSocketDisconnect when the client leaves
                    recv = asyncio.create_task(ws.receive_text())
                if getter in done:
                    await ws.send_json(getter.result())
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            recv.cancel()
            bus.unsubscribe(q)

    app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")
    return app
