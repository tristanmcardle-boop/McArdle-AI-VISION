/* VMS web UI - dependency-free single page app. */
'use strict';
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const S = { token: localStorage.getItem('vms-token') || '', cfg: {}, cams: [], brands: [], ws: null, unseen: 0, cleanup: [], page: '' };
const CLASSES = ['person', 'car', 'truck', 'bus', 'motorcycle', 'bicycle'];
const PAGES = { live: ['Live View', pageLive], playback: ['Playback', pagePlayback], events: ['Events', pageEvents],
  analytics: ['Analytics', pageAnalytics], cameras: ['Cameras', pageCameras], system: ['System', pageSystem] };

/* ---------- helpers ---------- */
async function api(path, o = {}) {
  o = { ...o, headers: { ...(o.headers || {}) } };
  if (S.token) o.headers.Authorization = 'Bearer ' + S.token;
  if (o.body && typeof o.body !== 'string') { o.body = JSON.stringify(o.body); o.headers['Content-Type'] = 'application/json'; }
  const r = await fetch('/api' + path, o);
  if (r.status === 401 && path !== '/login') { showLogin(); throw new Error('Session expired'); }
  if (!r.ok) {
    let m = r.statusText; try { const j = await r.json(); m = Array.isArray(j.detail) ? j.detail.map(d => d.msg).join('; ') : (j.detail || m); } catch { }
    throw new Error(m);
  }
  if (r.status === 204) return null;
  return (r.headers.get('content-type') || '').includes('json') ? r.json() : r;
}
const tq = () => 'token=' + encodeURIComponent(S.token);
function toast(msg, kind = '') { const t = document.createElement('div'); t.className = 'toast ' + kind; t.textContent = msg; $('#toast').append(t); setTimeout(() => t.remove(), 4500); }
const fail = e => toast(e.message || String(e), 'bad');
const fmtTime = ts => new Date(ts * 1000).toLocaleString([], { dateStyle: 'short', timeStyle: 'medium' });
const fmtHM = ts => new Date(ts * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
const fmtBytes = b => b > 1e9 ? (b / 1e9).toFixed(1) + ' GB' : b > 1e6 ? (b / 1e6).toFixed(1) + ' MB' : Math.round(b / 1e3) + ' KB';
const dayStart = d => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x.getTime() / 1000; };
const camName = id => (S.cams.find(c => c.id === id) || {}).name || ('Camera ' + id);
const empty = m => `<div class="empty">${m}</div>`;
function evDesc(e) {
  switch (e.type) {
    case 'line_cross': return `${esc(e.label)} <b>${esc(e.direction)}</b> · ${esc(e.rule_name)}`;
    case 'zone_enter': return `${esc(e.label)} entered · ${esc(e.rule_name)}`;
    case 'zone_dwell': return `${esc(e.label)} loitering · ${esc(e.rule_name)}`;
    case 'plate': return `<span class="plate">${esc(e.plate)}</span>`;
    default: return esc(e.type);
  }
}
const typeName = t => ({ line_cross: 'Line crossing', zone_enter: 'Zone entry', zone_dwell: 'Loitering', plate: 'LPR' }[t] || t);
function modal(title, body, foot = '', wide = false) {
  const m = $('#modal'); m.classList.remove('hidden');
  m.innerHTML = `<div class="box ${wide ? 'wide' : ''}"><div class="head">${title}<span class="sp"></span><button class="btn sm" data-close>✕</button></div><div class="body">${body}</div>${foot ? `<div class="foot">${foot}</div>` : ''}</div>`;
  m.onclick = e => { if (e.target === m || e.target.closest('[data-close]')) closeModal(); };
  return m;
}
function closeModal() { const m = $('#modal'); m.classList.add('hidden'); m.innerHTML = ''; }
function eventModal(e) {
  modal(`${typeName(e.type)} — ${esc(camName(e.camera_id))}`,
    `<p>${evDesc(e)}<br><span class="muted">${fmtTime(e.ts)}${e.confidence != null ? ' · conf ' + Math.round(e.confidence * 100) + '%' : ''}</span></p>
     ${e.snapshot || e.has_snap ? `<img src="/api/events/${e.id}/snapshot?${tq()}" alt="snapshot">` : '<p class="muted">No snapshot.</p>'}`, '', true);
}

/* ---------- theme / clock ---------- */
$('#theme').onclick = () => { const t = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = t; localStorage.setItem('vms-theme', t); window.dispatchEvent(new Event('vms-theme')); };
setInterval(() => $('#clock').textContent = new Date().toLocaleString([], { dateStyle: 'medium', timeStyle: 'medium' }), 1000);

/* ---------- auth / boot ---------- */
function showLogin() { S.token = ''; localStorage.removeItem('vms-token'); runCleanup(); if (S.ws) { S.ws.onclose = null; S.ws.close(); S.ws = null; } $('#app').classList.add('hidden'); $('#login').classList.remove('hidden'); $('#lp').value = ''; }
$('#login-form').onsubmit = async e => {
  e.preventDefault(); $('#login-err').textContent = '';
  try { const r = await api('/login', { method: 'POST', body: { username: $('#lu').value, password: $('#lp').value } }); S.token = r.token; localStorage.setItem('vms-token', r.token); boot(); }
  catch (er) { $('#login-err').textContent = er.message; }
};
$('#logout').onclick = showLogin;
$('#bell').onclick = () => { location.hash = '#events'; };

async function boot() {
  $('#login').classList.add('hidden'); $('#app').classList.remove('hidden');
  try { [S.brands, S.cams] = await Promise.all([api('/brands'), api('/cameras')]); } catch { return; }
  connectWS(); route();
}
function connectWS() {
  if (S.ws) { S.ws.onclose = null; S.ws.close(); }
  const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws/events?${tq()}`);
  ws.onmessage = m => {
    const e = JSON.parse(m.data); e.has_snap = !!e.snapshot;
    if (S.page !== 'events') { S.unseen++; $('#bell-n').textContent = S.unseen; $('#bell-n').classList.remove('hidden'); }
    window.dispatchEvent(new CustomEvent('vms-event', { detail: e }));
    if (e.type === 'plate') toast(`LPR: ${e.plate} · ${e.camera_name}`);
  };
  ws.onclose = () => { if (S.token) setTimeout(connectWS, 3000); };
  S.ws = ws;
}
function runCleanup() { S.cleanup.splice(0).forEach(f => { try { f(); } catch { } }); }
async function route() {
  if (!S.token) return;
  const name = (location.hash.slice(1) || 'live').split('?')[0];
  const [title, fn] = PAGES[name] || PAGES.live;
  runCleanup(); S.page = name; closeModal();
  $('#page-title').textContent = title;
  $$('.nav').forEach(b => b.classList.toggle('active', b.dataset.page === name));
  if (name === 'events') { S.unseen = 0; $('#bell-n').classList.add('hidden'); }
  try { S.cams = await api('/cameras'); } catch { return; }
  const v = $('#view'); v.innerHTML = '';
  try { await fn(v); } catch (e) { fail(e); }
}
$$('.nav').forEach(b => b.onclick = () => { location.hash = '#' + b.dataset.page; });
window.addEventListener('hashchange', route);
fetch('/api/config').then(r => r.json()).then(c => { S.cfg = c; document.title = c.brand; $('#brand').textContent = c.brand; $('#login-brand').textContent = c.brand; });
S.token ? boot() : showLogin();

/* ---------- LIVE ---------- */
async function pageLive(v) {
  let cols = +localStorage.getItem('vms-cols') || 2, focus = null, overlay = localStorage.getItem('vms-overlay') !== '0';
  v.innerHTML = `<div class="live"><aside class="panel tree"><div class="panel-h">Cameras</div><div class="tree-list" id="tree"></div></aside>
    <section class="live-main"><div class="toolbar"><span class="muted">Layout</span><span id="layouts"></span><span class="sp"></span>
    <button class="btn sm" id="ovl">Analytics overlay</button></div><div class="grid" id="grid"></div>
    <div><div class="muted" style="font-size:12px;margin-bottom:4px">Latest events</div><div class="evstrip" id="strip"></div></div></section></div>`;
  const cams = () => S.cams.filter(c => c.enabled);
  function tree() {
    $('#tree').innerHTML = S.cams.length ? S.cams.map(c => `<div class="tree-item" data-id="${c.id}"><span class="dot ${c.online ? 'on' : ''}"></span><div><div>${esc(c.name)}</div><div class="sub">${c.online ? c.resolution + ' · ' + c.fps + ' fps' : esc(c.error || 'offline')}</div></div></div>`).join('') : empty('No cameras yet');
    $$('.tree-item').forEach(el => el.onclick = () => { focus = focus === +el.dataset.id ? null : +el.dataset.id; grid(); });
  }
  function layouts() {
    $('#layouts').innerHTML = [1, 2, 3, 4].map(n => `<button class="btn sm ${n === cols && !focus ? 'on' : ''}" data-n="${n}">${n}×${n}</button>`).join(' ');
    $$('#layouts button').forEach(b => b.onclick = () => { cols = +b.dataset.n; focus = null; localStorage.setItem('vms-cols', cols); grid(); });
    $('#ovl').classList.toggle('on', overlay);
  }
  function grid() {
    $$('#grid img').forEach(i => i.src = '');
    const list = focus ? cams().filter(c => c.id === focus) : cams();
    const g = $('#grid'); g.style.gridTemplateColumns = `repeat(${focus ? 1 : cols},minmax(0,1fr))`;
    g.innerHTML = list.length ? list.map(c => `<div class="tile" data-id="${c.id}"><div class="tile-h"><span class="dot ${c.online ? 'on' : ''}"></span>${esc(c.name)}<span class="sp"></span><button data-act="focus" title="Maximise / restore">⤢</button></div>
      <img alt="${esc(c.name)}" src="/api/cameras/${c.id}/stream?overlay=${overlay ? 1 : 0}&width=${focus ? 1600 : 800}&${tq()}"><div class="tile-name">${esc(c.name)}</div></div>`).join('') : empty('No cameras to show. Add one under <b>Cameras</b>.');
    $$('.tile').forEach(t => { t.ondblclick = t.querySelector('[data-act=focus]').onclick = () => { focus = focus ? null : +t.dataset.id; grid(); }; });
    layouts();
  }
  $('#ovl').onclick = () => { overlay = !overlay; localStorage.setItem('vms-overlay', overlay ? 1 : 0); grid(); };
  const strip = async () => {
    const ev = await api('/events?limit=12');
    $('#strip').innerHTML = ev.length ? ev.map(e => `<div class="evcard" data-id="${e.id}"><img loading="lazy" src="/api/events/${e.id}/snapshot?${tq()}" onerror="this.style.visibility='hidden'"><div>${evDesc(e)}</div><div class="muted">${esc(camName(e.camera_id))} · ${fmtHM(e.ts)}</div></div>`).join('') : '<span class="muted">No events yet — draw a line or zone under Analytics.</span>';
    $$('.evcard').forEach((el, i) => el.onclick = () => eventModal(ev[i]));
  };
  const onEv = () => strip().catch(() => { });
  window.addEventListener('vms-event', onEv);
  const timer = setInterval(async () => { try { S.cams = await api('/cameras'); tree(); } catch { } }, 5000);
  S.cleanup.push(() => { clearInterval(timer); window.removeEventListener('vms-event', onEv); $$('#grid img').forEach(i => i.src = ''); });
  tree(); grid(); strip().catch(() => { });
}

/* ---------- EVENTS ---------- */
async function pageEvents(v) {
  let rows = [], filt = {};
  v.innerHTML = `<div class="panel"><div class="panel-b row"><select id="fc" style="width:200px"><option value="">All cameras</option>${S.cams.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select>
    <select id="ft" style="width:180px"><option value="">All event types</option><option value="line_cross">Line crossing</option><option value="zone_enter">Zone entry</option><option value="zone_dwell">Loitering</option><option value="plate">LPR</option></select>
    <input id="fp" type="text" placeholder="Plate contains…" style="width:160px"><input id="fd" type="date" style="width:160px">
    <span class="sp"></span><button class="btn" id="csv">Export CSV</button></div>
    <table><thead><tr><th></th><th>Time</th><th>Camera</th><th>Type</th><th>Detail</th><th>Conf.</th></tr></thead><tbody id="rows"></tbody></table>
    <div class="panel-b"><button class="btn" id="more">Load more</button></div></div>`;
  const qs = (extra = {}) => { const p = new URLSearchParams({ ...filt, ...extra }); return p.toString(); };
  function read() {
    filt = {}; if ($('#fc').value) filt.camera_id = $('#fc').value; if ($('#ft').value) filt.type = $('#ft').value; if ($('#fp').value) filt.plate = $('#fp').value;
    if ($('#fd').value) { const s = dayStart($('#fd').value + 'T00:00:00'); filt.from_ts = s; filt.to_ts = s + 86400; }
  }
  const draw = () => {
    $('#rows').innerHTML = rows.length ? rows.map((e, i) => `<tr class="click" data-i="${i}"><td>${e.snapshot ? `<img class="thumb" loading="lazy" src="/api/events/${e.id}/snapshot?${tq()}">` : ''}</td><td>${fmtTime(e.ts)}</td><td>${esc(camName(e.camera_id))}</td><td><span class="pill ${e.type}">${typeName(e.type)}</span></td><td>${evDesc(e)}</td><td>${e.confidence != null ? Math.round(e.confidence * 100) + '%' : ''}</td></tr>`).join('') : `<tr><td colspan="6">${empty('No events match.')}</td></tr>`;
    $$('#rows tr.click').forEach(tr => tr.onclick = () => eventModal(rows[+tr.dataset.i]));
  };
  const load = async (more = false) => {
    const extra = { limit: 50 }; if (more && rows.length) extra.before_id = rows[rows.length - 1].id;
    const r = await api('/events?' + qs(extra)); rows = more ? rows.concat(r) : r; $('#more').classList.toggle('hidden', r.length < 50); draw();
  };
  $$('select,input', v).forEach(el => el.onchange = () => { read(); load().catch(fail); });
  $('#more').onclick = () => load(true).catch(fail);
  $('#csv').onclick = async () => { const r = await api('/events/export.csv?' + qs()); const a = document.createElement('a'); a.href = URL.createObjectURL(await r.blob()); a.download = 'events.csv'; a.click(); };
  const onEv = ev => { const e = ev.detail; if ((!filt.camera_id || +filt.camera_id === e.camera_id) && (!filt.type || filt.type === e.type) && !filt.plate && !filt.from_ts) { rows.unshift(e); draw(); } };
  window.addEventListener('vms-event', onEv); S.cleanup.push(() => window.removeEventListener('vms-event', onEv));
  await load();
}

/* ---------- PLAYBACK ---------- */
async function pagePlayback(v) {
  if (!S.cams.length) { v.innerHTML = empty('Add a camera first.'); return; }
  const today = new Date(); const iso = d => d.toISOString().slice(0, 10);
  v.innerHTML = `<div class="pb"><div><div class="row" style="margin-bottom:10px"><select id="pc" style="width:220px">${S.cams.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select>
    <input type="date" id="pd" style="width:170px" value="${iso(new Date(today - today.getTimezoneOffset() * 6e4))}"></div>
    <video id="vid" controls autoplay muted></video><div class="muted" id="pinfo" style="margin-top:6px">Select a recording segment.</div></div>
    <div><div class="panel" style="margin-bottom:12px"><div class="panel-h">Recordings</div><div class="seglist" id="segs"></div></div>
    <div class="panel"><div class="panel-h">Events (click to jump)</div><div class="seglist" id="pev"></div></div></div></div>`;
  let segs = [], evs = [];
  const load = async () => {
    const cid = +$('#pc').value, s = dayStart($('#pd').value + 'T00:00:00'), e = s + 86400;
    [segs, evs] = await Promise.all([api(`/cameras/${cid}/recordings?from_ts=${s}&to_ts=${e}`), api(`/events?camera_id=${cid}&from_ts=${s}&to_ts=${e}&limit=200`)]);
    $('#segs').innerHTML = segs.length ? segs.map((g, i) => `<div class="seg" data-i="${i}"><span>${fmtHM(g.start)} – ${fmtHM(g.end)}</span><span class="muted">${fmtBytes(g.size)}</span></div>`).join('') : empty('No recordings for this day.');
    $$('#segs .seg').forEach(el => el.onclick = () => play(segs[+el.dataset.i], 0));
    $('#pev').innerHTML = evs.length ? evs.map((x, i) => `<div class="seg" data-i="${i}"><span>${fmtHM(x.ts)}</span><span>${evDesc(x)}</span></div>`).join('') : empty('No events.');
    $$('#pev .seg').forEach(el => el.onclick = () => { const x = evs[+el.dataset.i]; const g = segs.find(g => x.ts >= g.start && x.ts <= g.end + 5); g ? play(g, Math.max(0, x.ts - g.start - 3)) : toast('No recording covers this event', 'bad'); });
  };
  function play(g, off) {
    const vid = $('#vid'); vid.src = `/api/recordings/${$('#pc').value}/${g.name}?${tq()}`;
    vid.onloadedmetadata = () => { vid.currentTime = off; vid.play().catch(() => { }); };
    $('#pinfo').textContent = `Segment starting ${fmtTime(g.start)}`;
    $$('#segs .seg').forEach(el => el.classList.toggle('on', segs[+el.dataset.i] === g));
  }
  $('#pc').onchange = $('#pd').onchange = () => load().catch(fail);
  S.cleanup.push(() => { const vid = $('#vid'); if (vid) { vid.pause(); vid.src = ''; } });
  await load();
}

/* ---------- ANALYTICS ---------- */
async function pageAnalytics(v) {
  if (!S.cams.length) { v.innerHTML = empty('Add a camera first.'); return; }
  let camId = +sessionStorage.getItem('vms-an-cam'); if (!S.cams.find(c => c.id === camId)) camId = S.cams[0].id;
  let rules = [], img = new Image(), mode = null, pts = [], mouse = null;
  v.innerHTML = `<div class="row" style="margin-bottom:10px"><select id="ac" style="width:240px">${S.cams.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select>
    <button class="btn" data-mode="line">＋ Line (count / crossing)</button><button class="btn" data-mode="zone">＋ Zone (intrusion / loiter)</button><button class="btn" data-mode="lpr">＋ LPR</button>
    <button class="btn" id="snap">↻ Snapshot</button><span class="muted" id="hint"></span></div>
    <div class="an"><div><div class="canvas-wrap"><canvas id="ed"></canvas></div></div>
    <div><div class="panel" id="form" style="margin-bottom:12px"><div class="panel-h">Rules</div><div id="rules"></div></div></div></div>
    <h3 style="margin-top:16px">Today's counts</h3><div class="cards" id="cards"></div>
    <div class="panel"><div class="panel-h">Crossings per hour</div><div class="panel-b"><canvas class="chart" id="chart"></canvas></div></div>`;
  const cv = $('#ed'), cx = cv.getContext('2d');
  const COL = { line: '#00c8ff', zone: '#ff5a5a', lpr: '#ffc800' };
  const px = p => [p[0] * cv.width, p[1] * cv.height];
  function fit() { const w = cv.parentElement.clientWidth, ar = (img.naturalHeight || 9) / (img.naturalWidth || 16); cv.width = w; cv.height = Math.round(w * ar); }
  function arrow(a, b, inv) {
    const [ax, ay] = px(a), [bx, by] = px(b), mx = (ax + bx) / 2, my = (ay + by) / 2; let nx = -(by - ay), ny = bx - ax; const n = Math.hypot(nx, ny) || 1; const k = (inv ? -1 : 1) * 36 / n;
    cx.beginPath(); cx.moveTo(mx, my); cx.lineTo(mx + nx * k, my + ny * k); cx.stroke();
    const ex = mx + nx * k, ey = my + ny * k, ang = Math.atan2(ny * k, nx * k); cx.beginPath(); cx.moveTo(ex, ey); cx.lineTo(ex - 9 * Math.cos(ang - .5), ey - 9 * Math.sin(ang - .5)); cx.lineTo(ex - 9 * Math.cos(ang + .5), ey - 9 * Math.sin(ang + .5)); cx.closePath(); cx.fill();
  }
  function shape(type, points, name, inv, dashed, close) {
    if (!points.length) return; const c = COL[type]; cx.strokeStyle = cx.fillStyle = c; cx.lineWidth = 3; cx.setLineDash(dashed ? [8, 6] : []);
    cx.beginPath(); points.forEach((p, i) => { const [x, y] = px(p); i ? cx.lineTo(x, y) : cx.moveTo(x, y); }); if (close && points.length > 2) { cx.closePath(); cx.save(); cx.globalAlpha = .18; cx.fill(); cx.restore(); } cx.stroke(); cx.setLineDash([]);
    points.forEach(p => { const [x, y] = px(p); cx.beginPath(); cx.arc(x, y, 4, 0, 7); cx.fill(); });
    if (type === 'line' && points.length === 2) arrow(points[0], points[1], inv);
    if (name) { const [x, y] = px(points[0]); cx.font = '600 13px sans-serif'; cx.fillStyle = '#000b'; cx.fillRect(x, y - 22, cx.measureText(name).width + 10, 19); cx.fillStyle = c; cx.fillText(name, x + 5, y - 8); }
  }
  function draw() {
    cx.clearRect(0, 0, cv.width, cv.height); if (img.naturalWidth) cx.drawImage(img, 0, 0, cv.width, cv.height); else { cx.fillStyle = '#111'; cx.fillRect(0, 0, cv.width, cv.height); }
    rules.filter(r => r.enabled).forEach(r => { const p = r.params; if (r.type === 'lpr' && !p.points.length) return; shape(r.type, p.points, r.name, p.invert, r.type === 'lpr', r.type !== 'line'); });
    if (mode && pts.length) shape(mode, mouse && pts.length < (mode === 'line' ? 2 : 99) ? [...pts, mouse] : pts, '', false, true, mode !== 'line');
  }
  const snap = () => new Promise(res => { const i = new Image(); i.onload = () => { img = i; fit(); draw(); res(); }; i.onerror = () => { fit(); draw(); res(); }; i.src = `/api/cameras/${camId}/snapshot?overlay=0&${tq()}&t=${Date.now()}`; });
  const hint = t => $('#hint').textContent = t || '';
  function cancel() { mode = null; pts = []; mouse = null; hint(); $$('[data-mode]').forEach(b => b.classList.remove('on')); renderRules(); draw(); }
  function start(m) {
    cancel(); mode = m; $$('[data-mode]').forEach(b => b.classList.toggle('on', b.dataset.mode === m));
    hint(m === 'line' ? 'Click two points to draw the line.' : 'Click to add corners; double-click (or press Finish) to close the shape.');
    if (m === 'lpr') $('#rules').innerHTML = `<div class="panel-b"><p class="muted">Draw a region to restrict plate reading, or read the whole frame.</p><button class="btn" id="wf">Whole frame</button> <button class="btn" id="cn">Cancel</button></div>`, $('#wf').onclick = () => form(), $('#cn').onclick = cancel;
  }
  function finish() { if (mode === 'line' ? pts.length === 2 : pts.length >= 3) form(); else toast('Need more points', 'bad'); }
  function form() {
    const t = mode, cls = (t === 'lpr') ? '' : `<label>Detect</label><div>${CLASSES.map(c => `<label class="chk"><input type="checkbox" name="cls" value="${c}" ${c === 'person' ? 'checked' : ''}>${c}</label>`).join('')}</div>`;
    $('#rules').innerHTML = `<div class="panel-b"><label>Name</label><input type="text" id="rn" value="${t === 'line' ? 'Entrance' : t === 'zone' ? 'Restricted area' : 'Plate reader'}">${cls}
      ${t === 'line' ? `<label class="chk" style="margin-top:12px"><input type="checkbox" id="inv"> Reverse IN direction</label><p class="muted" style="font-size:12px">The arrow marks the <b>IN</b> direction.</p>` : ''}
      ${t === 'zone' ? `<label>Loitering alert after (seconds, 0 = off)</label><input type="number" id="dw" value="0" min="0">` : ''}
      ${t === 'lpr' ? `<label>Mode</label><select id="lm"><option value="vehicle">Read plates on detected vehicles</option><option value="frame">Dedicated plate camera (scan whole frame)</option></select><label>Minimum confidence (%)</label><input type="number" id="lc" value="60" min="10" max="99">` : ''}
      <div class="row" style="margin-top:14px"><button class="btn primary" id="sv">Save rule</button><button class="btn" id="cn">Cancel</button></div></div>`;
    $('#cn').onclick = cancel;
    $('#sv').onclick = async () => {
      const params = { points: pts };
      if (t !== 'lpr') params.classes = $$('[name=cls]:checked').map(i => i.value);
      if (t === 'line') params.invert = $('#inv').checked; if (t === 'zone') params.dwell_seconds = +$('#dw').value || 0;
      if (t === 'lpr') { params.mode = $('#lm').value; params.min_conf = (+$('#lc').value || 60) / 100; }
      try { await api(`/cameras/${camId}/rules`, { method: 'POST', body: { type: t, name: $('#rn').value || t, params } }); toast('Rule saved', 'ok'); cancel(); await loadRules(); loadCounts(); } catch (e) { fail(e); }
    };
  }
  function renderRules() {
    $('#rules').innerHTML = rules.length ? rules.map(r => `<div class="rule"><span class="t" style="color:${COL[r.type]}">${r.type}</span><span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis">${esc(r.name)}</span>
      <label class="chk" style="margin:0" title="Enabled"><input type="checkbox" data-en="${r.id}" ${r.enabled ? 'checked' : ''}></label><button class="btn sm danger" data-del="${r.id}">✕</button></div>`).join('') : `<div class="panel-b muted">No rules yet. Use the buttons above to draw a counting line, a zone or an LPR region.</div>`;
    $$('[data-en]').forEach(i => i.onchange = async () => { try { await api('/rules/' + i.dataset.en, { method: 'PATCH', body: { enabled: i.checked } }); await loadRules(); } catch (e) { fail(e); } });
    $$('[data-del]').forEach(b => b.onclick = async () => { if (!confirm('Delete this rule?')) return; try { await api('/rules/' + b.dataset.del, { method: 'DELETE' }); await loadRules(); loadCounts(); } catch (e) { fail(e); } });
  }
  async function loadRules() { rules = await api(`/cameras/${camId}/rules`); renderRules(); draw(); }
  async function loadCounts() {
    const d = await api(`/stats/counts?camera_id=${camId}&bucket=3600`), tot = {}, hours = Array.from({ length: 24 }, () => ({ in: 0, out: 0 }));
    d.rows.forEach(r => { const k = r.rule_id; (tot[k] = tot[k] || { name: r.rule_name, in: 0, out: 0 })[r.direction] += r.n; if (r.bucket >= 0 && r.bucket < 24) hours[r.bucket][r.direction] += r.n; });
    $('#cards').innerHTML = Object.values(tot).map(t => `<div class="panel stat"><span>${esc(t.name)}</span><b><span class="in">▼ ${t.in}</span> &nbsp; <span class="out">▲ ${t.out}</span></b><span>in / out</span></div>`).join('') || `<div class="muted">No line crossings recorded today.</div>`;
    bars($('#chart'), hours);
  }
  function bars(c, hours) {
    const dpr = devicePixelRatio || 1, w = c.clientWidth, h = c.clientHeight; c.width = w * dpr; c.height = h * dpr; const g = c.getContext('2d'); g.scale(dpr, dpr);
    const st = getComputedStyle(document.documentElement), txt = st.getPropertyValue('--muted'), line = st.getPropertyValue('--line'), ok = st.getPropertyValue('--ok'), warn = st.getPropertyValue('--warn');
    const max = Math.max(1, ...hours.map(x => Math.max(x.in, x.out))), bw = (w - 30) / 24; g.font = '11px sans-serif'; g.fillStyle = txt; g.strokeStyle = line;
    g.beginPath(); g.moveTo(26, h - 18); g.lineTo(w, h - 18); g.stroke(); g.fillText(max, 0, 12);
    hours.forEach((x, i) => { const X = 28 + i * bw; g.fillStyle = ok; g.fillRect(X + 1, h - 18 - (h - 36) * x.in / max, bw / 2 - 1, (h - 36) * x.in / max); g.fillStyle = warn; g.fillRect(X + bw / 2, h - 18 - (h - 36) * x.out / max, bw / 2 - 1, (h - 36) * x.out / max); if (i % 3 === 0) { g.fillStyle = txt; g.fillText(String(i).padStart(2, '0'), X, h - 5); } });
  }
  cv.onclick = e => {
    if (!mode) return;
    const r = cv.getBoundingClientRect(); pts.push([(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]);
    if (mode === 'line' && pts.length === 2) form(); else if (mode !== 'line' && pts.length >= 3) hint('Double-click (or press Enter) to finish this shape.');
    draw();
  };
  cv.ondblclick = () => { if (mode && mode !== 'line') { pts.pop(); finish(); } };
  cv.onmousemove = e => { if (!mode) return; const r = cv.getBoundingClientRect(); mouse = [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]; draw(); };
  $$('[data-mode]').forEach(b => b.onclick = () => start(b.dataset.mode));
  $('#snap').onclick = snap; $('#ac').value = camId;
  $('#ac').onchange = async () => { camId = +$('#ac').value; sessionStorage.setItem('vms-an-cam', camId); cancel(); await snap(); await loadRules(); loadCounts(); };
  const onEv = () => loadCounts().catch(() => { }), onTheme = () => loadCounts().catch(() => { }), onKey = e => { if (e.key === 'Escape') cancel(); if (e.key === 'Enter' && mode && mode !== 'line') finish(); }, onRz = () => { fit(); draw(); };
  window.addEventListener('vms-event', onEv); window.addEventListener('vms-theme', onTheme); window.addEventListener('keydown', onKey); window.addEventListener('resize', onRz);
  S.cleanup.push(() => { ['vms-event', 'vms-theme', 'keydown', 'resize'].forEach((n, i) => window.removeEventListener(n, [onEv, onTheme, onKey, onRz][i])); });
  await snap(); await loadRules(); loadCounts().catch(() => { });
}

/* ---------- CAMERAS ---------- */
async function pageCameras(v) {
  const draw = () => {
    v.innerHTML = `<div class="panel"><div class="panel-h">Cameras<span class="sp"></span><button class="btn primary" id="add">＋ Add camera</button></div>
      <table><thead><tr><th></th><th>Name</th><th>Type</th><th>Address</th><th>Stream</th><th>Record</th><th>Analytics</th><th></th></tr></thead><tbody>
      ${S.cams.map(c => `<tr><td><span class="dot ${c.online ? 'on' : ''}"></span></td><td><b>${esc(c.name)}</b>${c.error && c.enabled && !c.online ? `<div class="muted" style="font-size:12px">${esc(c.error)}</div>` : ''}</td>
      <td>${esc((S.brands.find(b => b.id === c.brand) || {}).label || c.brand)}</td><td>${esc(c.host || c.url.replace(/\/\/.*@/, '//***@'))}</td><td>${c.online ? c.resolution : '—'}</td><td>${c.recording ? '● rec' : c.record ? 'on' : 'off'}</td><td>${c.analytics ? 'on' : 'off'}</td>
      <td style="white-space:nowrap"><button class="btn sm" data-edit="${c.id}">Edit</button> <button class="btn sm danger" data-del="${c.id}">Delete</button></td></tr>`).join('') || `<tr><td colspan="8">${empty('No cameras yet. Click <b>Add camera</b> — any RTSP / ONVIF / HTTP camera works.')}</td></tr>`}</tbody></table></div>`;
    $('#add').onclick = () => editor(); $$('[data-edit]').forEach(b => b.onclick = () => editor(S.cams.find(c => c.id === +b.dataset.edit)));
    $$('[data-del]').forEach(b => b.onclick = async () => { if (confirm('Delete this camera and its rules?')) { try { await api('/cameras/' + b.dataset.del, { method: 'DELETE' }); S.cams = await api('/cameras'); draw(); } catch (e) { fail(e); } } });
  };
  function editor(cam) {
    const c = cam || { name: '', brand: 'generic', host: '', port: 0, username: '', password: '', channel: 1, stream: 'main', url: '', enabled: true, record: true, analytics: true };
    const m = modal(cam ? 'Edit camera' : 'Add camera', `<label>Name</label><input type="text" id="f-name" value="${esc(c.name)}" placeholder="e.g. Front gate">
      <label>Camera type / brand</label><select id="f-brand">${S.brands.map(b => `<option value="${b.id}" ${b.id === c.brand ? 'selected' : ''}>${esc(b.label)}</option>`).join('')}</select>
      <div id="f-host-wrap"><div class="grid2"><div><label id="f-host-l">IP address / host</label><input type="text" id="f-host" value="${esc(c.host)}"></div><div data-f="port"><label>Port</label><input type="number" id="f-port" value="${c.port || ''}"></div></div></div>
      <div data-f="auth" class="grid2"><div><label>Username</label><input type="text" id="f-user" value="${esc(c.username)}" autocomplete="off"></div><div><label>Password</label><input type="password" id="f-pass" placeholder="${c.has_password ? '(unchanged)' : ''}" autocomplete="new-password"></div></div>
      <div class="grid2"><div data-f="channel"><label>Channel</label><input type="number" id="f-ch" min="1" value="${c.channel || 1}"></div><div data-f="stream"><label>Stream</label><select id="f-stream"><option value="main">Main (high quality)</option><option value="sub" ${c.stream === 'sub' ? 'selected' : ''}>Sub (lower load)</option></select></div></div>
      <div data-f="url"><label id="f-url-l">Stream URL (rtsp://…, http://…mjpeg) or file path</label><input type="text" id="f-url" value="${esc(c.url)}" placeholder="rtsp://user:pass@192.168.1.10:554/stream"></div>
      <div style="margin-top:10px"><label class="chk"><input type="checkbox" id="f-en" ${c.enabled ? 'checked' : ''}>Enabled</label><label class="chk"><input type="checkbox" id="f-rec" ${c.record ? 'checked' : ''}>Record</label><label class="chk"><input type="checkbox" id="f-an" ${c.analytics ? 'checked' : ''}>Run analytics</label></div>
      <div class="chips" id="found"></div><div id="tres" class="muted" style="margin-top:8px"></div>`,
      `<button class="btn" id="disc">Discover ONVIF cameras</button><span class="sp"></span><button class="btn" id="test">Test connection</button><button class="btn primary" id="save">Save</button>`);
    const upd = () => {
      const b = S.brands.find(x => x.id === $('#f-brand').value) || { fields: [] }, f = b.fields, has = k => f.includes(k);
      $$('[data-f]', m).forEach(el => el.classList.toggle('hidden', !has(el.dataset.f)));
      $('#f-host-wrap').classList.toggle('hidden', !has('host')); $('#f-host-l').textContent = b.id === 'usb' ? 'Device index (0, 1, …)' : 'IP address / host';
      if (has('port') && !$('#f-port').value) $('#f-port').value = b.port || ''; if (b.id === 'file') $('#f-url-l').textContent = 'Video file path (on the server)';
    };
    const read = () => ({ name: $('#f-name').value.trim(), brand: $('#f-brand').value, host: $('#f-host').value.trim(), port: +$('#f-port').value || 0, username: $('#f-user').value, password: $('#f-pass').value, channel: +$('#f-ch').value || 1, stream: $('#f-stream').value, url: $('#f-url').value.trim(), enabled: $('#f-en').checked, record: $('#f-rec').checked, analytics: $('#f-an').checked });
    $('#f-brand').onchange = () => { $('#f-port').value = ''; upd(); }; upd();
    $('#disc').onclick = async () => { $('#found').innerHTML = '<span class="muted">Scanning network…</span>'; try { const d = await api('/discover'); $('#found').innerHTML = d.length ? d.map(x => `<span class="chip" data-ip="${esc(x.ip)}" data-port="${x.port}">${esc(x.name || x.hardware || 'Camera')} · ${esc(x.ip)}</span>`).join('') : '<span class="muted">No ONVIF cameras answered (multicast may be blocked — see README).</span>'; $$('.chip', m).forEach(ch => ch.onclick = () => { $('#f-brand').value = 'onvif'; upd(); $('#f-host').value = ch.dataset.ip; $('#f-port').value = ch.dataset.port; if (!$('#f-name').value) $('#f-name').value = ch.textContent.split(' · ')[0]; }); } catch (e) { fail(e); } };
    $('#test').onclick = async () => { $('#tres').textContent = 'Connecting…'; try { const r = await api('/cameras/test', { method: 'POST', body: read() }); $('#tres').innerHTML = r.ok ? `<span style="color:var(--ok)">✔ Connected — ${r.width}×${r.height}</span>` : `<span style="color:var(--bad)">✖ ${esc(r.error)}</span>`; } catch (e) { $('#tres').textContent = e.message; } };
    $('#save').onclick = async () => { try { await api(cam ? '/cameras/' + cam.id : '/cameras', { method: cam ? 'PUT' : 'POST', body: read() }); closeModal(); S.cams = await api('/cameras'); draw(); toast('Camera saved', 'ok'); } catch (e) { fail(e); } };
  }
  const timer = setInterval(async () => { if ($('#modal').classList.contains('hidden')) { try { S.cams = await api('/cameras'); draw(); } catch { } } }, 6000);
  S.cleanup.push(() => clearInterval(timer)); draw();
}

/* ---------- SYSTEM ---------- */
async function pageSystem(v) {
  const s = await api('/system'), ok = b => b ? '<span style="color:var(--ok)">● Ready</span>' : '<span style="color:var(--bad)">● Unavailable</span>';
  v.innerHTML = `<div class="panel" style="max-width:820px"><div class="panel-h">${esc(s.brand)} · v${esc(s.version)}</div><div class="panel-b kv">
    <div>Cameras online</div><div>${s.cameras.online} / ${s.cameras.total}</div>
    <div>Object detector</div><div>${ok(s.detector.ready)} · ${esc(s.detector.model)} (${esc(s.detector.device)})${s.detector.error ? `<div class="muted" style="font-size:12px">${esc(s.detector.error)}</div>` : ''}</div>
    <div>Analytics rate</div><div>${s.analytics_fps} fps per camera</div>
    <div>LPR engine</div><div>${s.lpr.loaded ? (s.lpr.backend ? '<span style="color:var(--ok)">● ' + esc(s.lpr.backend) + '</span>' : '<span style="color:var(--bad)">● none installed</span><div class="muted" style="font-size:12px">' + esc(s.lpr.error) + '</div>') : '<span class="muted">Loads on first use</span>'}</div>
    <div>Recording</div><div>${s.recording.enabled ? ok(true) : ok(false) + (s.recording.ffmpeg ? ' (disabled)' : ' — ffmpeg not found')} · ${s.recording.segment_seconds}s segments · keep ${s.recording.retention_days} days · ${fmtBytes(s.recording.used_bytes)} used</div>
    <div>Disk (data volume)</div><div>${fmtBytes(s.disk.free)} free of ${fmtBytes(s.disk.total)}</div></div></div>`;
}
