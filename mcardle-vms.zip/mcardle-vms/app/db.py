"""SQLite storage: cameras, analytics rules, events."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS cameras(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, brand TEXT NOT NULL DEFAULT 'generic',
  host TEXT DEFAULT '', port INTEGER DEFAULT 0,
  username TEXT DEFAULT '', password TEXT DEFAULT '',
  channel INTEGER DEFAULT 1, stream TEXT DEFAULT 'main', url TEXT DEFAULT '',
  enabled INTEGER DEFAULT 1, record INTEGER DEFAULT 1, analytics INTEGER DEFAULT 1,
  created REAL);
CREATE TABLE IF NOT EXISTS rules(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  camera_id INTEGER NOT NULL REFERENCES cameras(id) ON DELETE CASCADE,
  type TEXT NOT NULL, name TEXT NOT NULL, params TEXT NOT NULL DEFAULT '{}',
  enabled INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL, camera_id INTEGER NOT NULL, rule_id INTEGER, rule_name TEXT,
  type TEXT NOT NULL, label TEXT, direction TEXT, plate TEXT,
  confidence REAL, snapshot TEXT);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
CREATE INDEX IF NOT EXISTS idx_events_cam ON events(camera_id, ts);
"""

CAMERA_FIELDS = ("name", "brand", "host", "port", "username", "password", "channel",
                 "stream", "url", "enabled", "record", "analytics")


class DB:
    def __init__(self, path: Path | str) -> None:
        self.conn = sqlite3.connect(str(path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA foreign_keys=ON")
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    # -- helpers -----------------------------------------------------------
    def q(self, sql: str, args: tuple = ()) -> list[dict]:
        with self.lock:
            return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    def one(self, sql: str, args: tuple = ()) -> dict | None:
        rows = self.q(sql, args)
        return rows[0] if rows else None

    def x(self, sql: str, args: tuple = ()) -> int:
        with self.lock:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur.lastrowid or 0

    # -- cameras -----------------------------------------------------------
    def cameras(self) -> list[dict]:
        return self.q("SELECT * FROM cameras ORDER BY id")

    def camera(self, cid: int) -> dict | None:
        return self.one("SELECT * FROM cameras WHERE id=?", (cid,))

    def camera_create(self, d: dict) -> int:
        vals = [int(d[k]) if isinstance(d[k], bool) else d[k] for k in CAMERA_FIELDS]
        return self.x(
            f"INSERT INTO cameras({','.join(CAMERA_FIELDS)},created) "
            f"VALUES({','.join('?' * len(CAMERA_FIELDS))},?)", (*vals, time.time()))

    def camera_update(self, cid: int, d: dict) -> None:
        cols = [k for k in CAMERA_FIELDS if k in d]
        vals = [int(d[k]) if isinstance(d[k], bool) else d[k] for k in cols]
        if cols:
            self.x(f"UPDATE cameras SET {','.join(c + '=?' for c in cols)} WHERE id=?", (*vals, cid))

    def camera_delete(self, cid: int) -> None:
        self.x("DELETE FROM cameras WHERE id=?", (cid,))

    # -- rules -------------------------------------------------------------
    @staticmethod
    def _rule(r: dict) -> dict:
        r["params"] = json.loads(r["params"] or "{}")
        r["enabled"] = bool(r["enabled"])
        return r

    def rules(self, camera_id: int | None = None) -> list[dict]:
        if camera_id is None:
            rows = self.q("SELECT * FROM rules ORDER BY id")
        else:
            rows = self.q("SELECT * FROM rules WHERE camera_id=? ORDER BY id", (camera_id,))
        return [self._rule(r) for r in rows]

    def rule(self, rid: int) -> dict | None:
        r = self.one("SELECT * FROM rules WHERE id=?", (rid,))
        return self._rule(r) if r else None

    def rule_create(self, camera_id: int, type_: str, name: str, params: dict, enabled=True) -> int:
        return self.x("INSERT INTO rules(camera_id,type,name,params,enabled) VALUES(?,?,?,?,?)",
                      (camera_id, type_, name, json.dumps(params), int(enabled)))

    def rule_update(self, rid: int, name: str | None, params: dict | None, enabled: bool | None) -> None:
        if name is not None:
            self.x("UPDATE rules SET name=? WHERE id=?", (name, rid))
        if params is not None:
            self.x("UPDATE rules SET params=? WHERE id=?", (json.dumps(params), rid))
        if enabled is not None:
            self.x("UPDATE rules SET enabled=? WHERE id=?", (int(enabled), rid))

    def rule_delete(self, rid: int) -> None:
        self.x("DELETE FROM rules WHERE id=?", (rid,))

    # -- events ------------------------------------------------------------
    def event_add(self, e: dict) -> int:
        return self.x(
            "INSERT INTO events(ts,camera_id,rule_id,rule_name,type,label,direction,plate,confidence,snapshot)"
            " VALUES(?,?,?,?,?,?,?,?,?,?)",
            (e["ts"], e["camera_id"], e.get("rule_id"), e.get("rule_name"), e["type"],
             e.get("label"), e.get("direction"), e.get("plate"), e.get("confidence"), e.get("snapshot")))

    def events(self, camera_id=None, type_=None, plate=None, from_ts=None, to_ts=None,
               before_id=None, limit=100) -> list[dict]:
        where, args = [], []
        for cond, val in (("camera_id=?", camera_id), ("type=?", type_), ("ts>=?", from_ts),
                          ("ts<=?", to_ts), ("id<?", before_id)):
            if val is not None:
                where.append(cond)
                args.append(val)
        if plate:
            where.append("plate LIKE ?")
            args.append(f"%{plate.upper()}%")
        sql = "SELECT * FROM events" + (" WHERE " + " AND ".join(where) if where else "")
        return self.q(sql + " ORDER BY id DESC LIMIT ?", (*args, max(1, min(limit, 1000))))

    def event(self, eid: int) -> dict | None:
        return self.one("SELECT * FROM events WHERE id=?", (eid,))

    def counts(self, camera_id: int | None, from_ts: float, to_ts: float, bucket: int = 3600) -> list[dict]:
        where, args = "type='line_cross' AND ts>=? AND ts<=?", [from_ts, to_ts]
        if camera_id is not None:
            where += " AND camera_id=?"
            args.append(camera_id)
        return self.q(
            f"SELECT rule_id, rule_name, label, direction, "
            f"CAST((ts-?)/? AS INTEGER) AS bucket, COUNT(*) AS n FROM events WHERE {where} "
            f"GROUP BY rule_id, rule_name, label, direction, bucket ORDER BY bucket",
            (from_ts, bucket, *args))

    def purge_events(self, before_ts: float) -> list[str]:
        paths = [r["snapshot"] for r in self.q(
            "SELECT snapshot FROM events WHERE ts<? AND snapshot IS NOT NULL", (before_ts,))]
        self.x("DELETE FROM events WHERE ts<?", (before_ts,))
        return paths
