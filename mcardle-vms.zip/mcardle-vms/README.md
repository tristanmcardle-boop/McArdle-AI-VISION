# McArdle AI VMS

An open, **brand-agnostic video management system (VMS)** with built-in AI analytics.
Connect cameras from any manufacturer, watch them live, record continuously, and turn them into
smart sensors that **count people and vehicles, detect line crossings, watch zones and read licence plates**.

The web interface follows the layout of enterprise VMS clients such as CathexisVision — icon rail,
camera tree, live grid, playback, event log — with a one-click **light / dark** switch.

> Rename it anywhere with `VMS_BRAND` (shown in the header, login page and browser tab).

## Features

| Area | What you get |
|---|---|
| **Any camera** | RTSP, HTTP-MJPEG, ONVIF (auto-discovery + stream lookup), USB webcams, video files. Presets for Hikvision, Dahua/Amcrest, Axis, Uniview, Hanwha, Bosch, Vivotek, Reolink, TP-Link Tapo, Foscam. Anything else: paste its URL. |
| **Live view** | 1×1 – 4×4 grid, maximise on double-click, analytics overlay on/off, auto-reconnect with back-off. |
| **Recording & playback** | Continuous recording with `ffmpeg -c copy` (no transcoding, minimal CPU), day view, jump-to-event playback, retention in days. |
| **Line crossing / people & vehicle counting** | Draw a line on the camera image; every crossing is logged as **in** or **out** per class (person, car, truck, bus, motorcycle, bicycle). Hourly charts and totals. |
| **Zones** | Intrusion (entry) and loitering (dwell time) alerts inside any polygon. |
| **LPR** | Plate reading on detected vehicles, or a dedicated "scan the whole frame" mode for ANPR cameras. De-duplication window, confidence threshold, optional country regex. |
| **Events** | Searchable log with annotated snapshot, CSV export, live push over WebSocket. |
| **Light / dark UI** | Theme follows the OS by default and is remembered per browser. |

## Architecture

```
 cameras ──RTSP/HTTP/ONVIF──► CameraSource (thread, auto-reconnect)
                                  │ latest frame
                                  ▼
                    CameraWorker ── YOLO detector (shared) ─► IoU tracker ─► rules
                                  │                                  (line · zone · LPR)
                                  │ events + snapshots                        │
       ffmpeg segmenter ◄─────────┼───────────────────────────────────────────┘
       (recordings)               ▼
                 SQLite (cameras, rules, events) ─► FastAPI ─► MJPEG streams / REST / WebSocket ─► web UI
```

Frames are analysed at `VMS_ANALYTICS_FPS` (default 5) while the live view stays smooth: overlays are
drawn on top of the full-rate stream using the latest analytics result.

## Quick start

### Docker (recommended)

```bash
cp .env.example .env          # set VMS_ADMIN_PASSWORD!
docker compose up -d --build
```

Open <http://localhost:8000> and sign in with `VMS_ADMIN_USER` / `VMS_ADMIN_PASSWORD`.

### Local Python (3.10+, ffmpeg on PATH)

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -r requirements-optional.txt                # LPR + ONVIF (optional)
export VMS_ADMIN_PASSWORD=change-me-now                 # Windows: set VMS_ADMIN_PASSWORD=...
uvicorn app.main:create_app --factory --host 0.0.0.0 --port 8000
```

The first start downloads the YOLO weights (`yolov8n.pt`). Data lives in `./data` (`VMS_DATA_DIR`).

### Try it without a camera

*Cameras → Add camera → type "Video file"* and give a path to any MP4 containing people or cars.
The file loops, so you can draw a line and watch the counters.

## Using it

1. **Cameras → Add camera.** Pick the brand, enter IP / credentials, press **Test connection**, save.
   *Discover ONVIF cameras* scans the LAN. Unlisted brand? choose *Generic* and paste the stream URL.
2. **Analytics.** Pick a camera, press **＋ Line**, click two points on the picture. The arrow marks the
   **IN** direction (tick *Reverse* to flip). Zones: click the corners, double-click to finish.
   **＋ LPR** limits plate reading to a region, or reads the whole frame.
3. **Live** shows boxes, IDs, counters and plates. **Events** lists everything with snapshots.
   **Playback** plays the recording and jumps to any event.

Tips: use the camera's **sub stream** for analytics-only cameras; put the counting line where people
cannot linger; for LPR the plate should be ≥ ~100 px wide with the camera angled < 30° off the car's axis.

## Configuration (environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `VMS_BRAND` | `McArdle AI VMS` | Product name in the UI |
| `VMS_ADMIN_USER` / `VMS_ADMIN_PASSWORD` | `admin` / `admin` | Login — **change the password** |
| `VMS_DATA_DIR` | `./data` | Database, snapshots, recordings |
| `VMS_MODEL` | `yolov8n.pt` | Any Ultralytics model (`yolov8s.pt`, `yolo11n.pt`, your own…) |
| `VMS_DEVICE` | auto | `cpu`, `cuda:0`, `mps` |
| `VMS_CONF` / `VMS_IMGSZ` | `0.35` / `640` | Detection threshold / input size |
| `VMS_ANALYTICS_FPS` | `5` | Analysis rate per camera |
| `VMS_PLATE_REGEX` | – | Accept only plates matching this regex, e.g. `[A-Z]{2}\d{6}` |
| `VMS_RECORD` | `1` | Master switch for recording |
| `VMS_SEGMENT_SECONDS` / `VMS_RETENTION_DAYS` | `300` / `7` | Recording file length / how long to keep recordings + events |
| `VMS_STREAM_FPS` / `VMS_STREAM_QUALITY` | `12` / `70` | Live-view frame rate / JPEG quality |
| `VMS_SECRET`, `VMS_TOKEN_TTL_HOURS` | generated / `12` | Token signing secret (persisted in the data dir) and lifetime |

## LPR set-up

LPR needs one backend; the first that imports is used:

* `pip install "fast-alpr[onnx]"` — plate detector + OCR (recommended; included in the Docker image)
* `pip install easyocr` — fallback OCR on the vehicle crop

*System → LPR engine* shows what was found. Set `VMS_PLATE_REGEX` for your country's format to cut false reads.

## REST API (all under `/api`, Bearer token)

`POST /login` · `GET/POST /cameras` · `PUT/DELETE /cameras/{id}` · `POST /cameras/test` · `GET /discover` ·
`GET /cameras/{id}/stream` (MJPEG) · `GET /cameras/{id}/snapshot` · `GET/POST /cameras/{id}/rules` ·
`PATCH/DELETE /rules/{id}` · `GET /events` · `GET /events/export.csv` · `GET /events/{id}/snapshot` ·
`GET /stats/counts` · `GET /cameras/{id}/recordings` · `GET /system` · WebSocket `/ws/events?token=…`.
Interactive docs: `/docs`.

## Security notes

* Put it behind HTTPS (Caddy / nginx / Traefik) before exposing it beyond your LAN.
* Camera passwords are stored in plain text in `data/vms.db` (they must be replayed to the camera) — protect the data volume.
* Browsers can't send headers on `<img>` / `<video>`, so media URLs carry the session token in the query string.
* `ffmpeg` receives the camera URL (with credentials) as a process argument.
* Only a single admin account exists today (see roadmap).

## Development

```bash
pip install -r requirements-dev.txt
pytest -q                      # geometry, tracker, brands, DB, API and an end-to-end synthetic-video pipeline test
```

Layout: `app/camera` (sources, brand presets, ONVIF) · `app/analytics` (detector, tracker, rules, LPR, overlay) ·
`app/engine.py` (workers) · `app/recorder.py` · `app/main.py` (API) · `app/static` (UI, no build step).

Adding an analytic = a `Rule` subclass in `app/analytics/rules.py` (`process(tracks, ts, worker)`), a branch in
`validate_params`, and a drawing mode in the Analytics page.

## Roadmap

Multi-user roles · ByteTrack / ReID tracker · plate watch-lists with alerts · webhooks / MQTT / e-mail notifications ·
PTZ control via ONVIF · event-triggered clip export · multi-server federation · HLS/WebRTC live view for large grids.

## Publish to GitHub

```bash
git init -b main && git add . && git commit -m "Initial commit: AI VMS"
git remote add origin https://github.com/<you>/<repo>.git && git push -u origin main
```

Edit the copyright line in `LICENSE` first.
