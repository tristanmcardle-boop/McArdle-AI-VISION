import time

from app.analytics.geometry import iou, line_cross, point_in_polygon, side
from app.analytics.lpr import normalize_plate, plausible
from app.analytics.rules import validate_params
from app.analytics.tracker import IoUTracker
from app.analytics.types import Detection
from app.camera.brands import build_url, inject_auth
from app.camera.discovery import parse_response
from app.db import DB
from app.security import make_token, verify_token


def test_line_cross_direction_and_extent():
    a, b = (0.0, 0.5), (1.0, 0.5)          # left -> right line; positive side is below it
    assert line_cross(a, b, (0.5, 0.4), (0.5, 0.6)) == 1
    assert line_cross(a, b, (0.5, 0.6), (0.5, 0.4)) == -1
    assert line_cross(a, b, (0.5, 0.4), (0.5, 0.45)) == 0          # no crossing
    short = ((0.4, 0.5), (0.6, 0.5))
    assert line_cross(*short, (0.9, 0.4), (0.9, 0.6)) == 0           # crosses extension, not the segment
    assert side(a, b, (0.5, 0.9)) > 0


def test_point_in_polygon_and_iou():
    sq = [(0.2, 0.2), (0.8, 0.2), (0.8, 0.8), (0.2, 0.8)]
    assert point_in_polygon((0.5, 0.5), sq) and not point_in_polygon((0.1, 0.5), sq)
    assert iou((0, 0, 10, 10), (0, 0, 10, 10)) == 1 and iou((0, 0, 1, 1), (5, 5, 6, 6)) == 0


def test_tracker_keeps_identity_for_moving_object():
    tr, ids = IoUTracker(), set()
    for i in range(10):
        out = tr.update([Detection((10 + i * 8, 20, 60 + i * 8, 120), "person", 0.9)], i * 0.2)
        ids |= {t.id for t in out}
    assert len(ids) == 1


def test_tracker_separates_two_people():
    tr = IoUTracker()
    for i in range(4):
        out = tr.update([Detection((10, 10, 60, 110), "person", .9), Detection((300, 10, 350, 110), "person", .9)], i)
    assert len({t.id for t in out}) == 2


def test_brand_urls():
    cam = {"brand": "hikvision", "host": "10.0.0.5", "port": 0, "username": "admin", "password": "p@ss/w", "channel": 2, "stream": "sub"}
    assert build_url(cam) == "rtsp://admin:p%40ss%2Fw@10.0.0.5:554/Streaming/Channels/202"
    assert build_url({**cam, "brand": "dahua", "stream": "main"}).endswith("channel=2&subtype=0")
    assert build_url({"brand": "generic", "url": "rtsp://x/y"}) == "rtsp://x/y"
    assert build_url({"brand": "usb", "host": "1"}) == 1
    assert inject_auth("rtsp://1.2.3.4/s", {"username": "u", "password": "p"}) == "rtsp://u:p@1.2.3.4/s"


def test_onvif_probe_match_parsing():
    xml = ("<d:XAddrs>http://192.168.1.50:8000/onvif/device_service</d:XAddrs>"
           "<d:Scopes>onvif://www.onvif.org/name/Front%20Cam onvif://www.onvif.org/hardware/DS-2CD</d:Scopes>")
    d = parse_response(xml)
    assert d["ip"] == "192.168.1.50" and d["port"] == 8000 and d["name"] == "Front Cam"


def test_plate_helpers():
    assert normalize_plate("nd 123-456") == "ND123456"
    assert plausible("ND123456") and not plausible("ABCDEF") and not plausible("A1")
    assert plausible("CA123456", r"[A-Z]{2}\d{6}") and not plausible("ND12345X", r"[A-Z]{2}\d{6}")


def test_rule_validation():
    p = validate_params("line", {"points": [[0, 0.5], [1.5, 0.5]], "classes": ["person", "dragon"]})
    assert p["points"][1] == [1.0, 0.5] and p["classes"] == ["person"]
    for bad in (("line", {"points": [[0, 0]]}), ("zone", {"points": [[0, 0], [1, 1]]}), ("nope", {})):
        try:
            validate_params(*bad)
            raise AssertionError("should fail")
        except ValueError:
            pass
    assert validate_params("lpr", {})["points"] == []


def test_token_roundtrip():
    t = make_token("s3cret", "admin", 60)
    assert verify_token("s3cret", t) == "admin" and verify_token("other", t) is None
    assert verify_token("s3cret", make_token("s3cret", "admin", -1)) is None
    assert verify_token("s3cret", "garbage") is None


def test_db_roundtrip(tmp_path):
    db = DB(tmp_path / "t.db")
    cam = dict(name="c", brand="generic", host="", port=0, username="", password="", channel=1,
               stream="main", url="rtsp://x", enabled=True, record=True, analytics=True)
    cid = db.camera_create(cam)
    rid = db.rule_create(cid, "line", "L", {"points": [[0, .5], [1, .5]]})
    now = time.time()
    for d in ("in", "in", "out"):
        db.event_add({"ts": now, "camera_id": cid, "rule_id": rid, "rule_name": "L", "type": "line_cross",
                      "label": "person", "direction": d})
    rows = db.counts(cid, now - 10, now + 10, 3600)
    assert {(r["direction"], r["n"]) for r in rows} == {("in", 2), ("out", 1)}
    assert len(db.events(camera_id=cid, limit=2)) == 2
    db.camera_delete(cid)
    assert db.rules(cid) == []        # cascade
