"""End-to-end analytics test with a synthetic video and a scripted detector (no GPU / model needed)."""
import time
import types

import cv2
import numpy as np

from app.analytics.types import Detection
from app.db import DB
from app.engine import Engine
from app.eventbus import EventBus


class ScriptedDetector:
    """Reports one 'person' that walks top -> bottom across the frame, then returns."""
    ready, error = True, ""

    def __init__(self):
        self.i = 0

    def detect(self, frame):
        h, w = frame.shape[:2]
        k = self.i % 40
        self.i += 1
        y = (k / 20 if k <= 20 else 2 - k / 20) * (h - 120)        # down, then back up
        return [Detection((w / 2 - 25, y, w / 2 + 25, y + 100), "person", 0.9)]


def make_video(path, n=60):
    vw = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 30, (320, 240))
    for i in range(n):
        vw.write(np.full((240, 320, 3), 40 + i, np.uint8))
    vw.release()


def test_line_crossing_events(tmp_path):
    vid = tmp_path / "t.mp4"
    make_video(vid)
    settings = types.SimpleNamespace(analytics_fps=30.0, plate_regex="", snapshots_dir=tmp_path / "snaps")
    settings.snapshots_dir.mkdir()
    db, bus = DB(tmp_path / "t.db"), EventBus()
    cid = db.camera_create(dict(name="test", brand="file", host="", port=0, username="", password="", channel=1,
                                stream="main", url=str(vid), enabled=True, record=False, analytics=True))
    db.rule_create(cid, "line", "Gate", {"points": [[0.0, 0.5], [1.0, 0.5]], "classes": ["person"],
                                         "invert": False, "anchor": "bottom"})
    eng = Engine(settings, db, bus, ScriptedDetector())
    eng.start_camera(db.camera(cid))
    deadline = time.time() + 20
    try:
        while time.time() < deadline and len(db.events(cid)) < 2:
            time.sleep(0.2)
    finally:
        eng.stop()
    ev = db.events(cid, limit=50)
    dirs = {e["direction"] for e in ev if e["type"] == "line_cross"}
    assert dirs == {"in", "out"}, ev          # walked down (in) and back up (out)
    snap = settings.snapshots_dir / ev[0]["snapshot"]
    assert snap.exists() and snap.stat().st_size > 500
