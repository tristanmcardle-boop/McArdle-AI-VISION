import importlib

import pytest

pytest.importorskip("fastapi")
from fastapi.testclient import TestClient  # noqa: E402


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("VMS_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("VMS_ADMIN_PASSWORD", "pw")
    monkeypatch.setenv("VMS_RECORD", "0")
    import app.config as config
    config.get_settings.cache_clear()
    import app.main as main
    importlib.reload(main)
    with TestClient(main.create_app()) as c:
        yield c
    config.get_settings.cache_clear()


def auth(c):
    r = c.post("/api/login", json={"username": "admin", "password": "pw"})
    assert r.status_code == 200
    return {"Authorization": "Bearer " + r.json()["token"]}


def test_auth_required(client):
    assert client.get("/api/cameras").status_code == 401
    assert client.post("/api/login", json={"username": "admin", "password": "bad"}).status_code == 401
    assert client.get("/api/config").json()["brand"]


def test_camera_and_rule_crud(client):
    h = auth(client)
    assert len(client.get("/api/brands", headers=h).json()) > 5
    r = client.post("/api/cameras", headers=h, json={"name": "Gate", "brand": "hikvision", "host": "10.0.0.9",
                                                      "username": "a", "password": "secret", "enabled": False})
    assert r.status_code == 201 and "password" not in r.json() and r.json()["has_password"]
    cid = r.json()["id"]
    assert client.post("/api/cameras", headers=h, json={"name": "x", "brand": "generic"}).status_code == 422
    rule = client.post(f"/api/cameras/{cid}/rules", headers=h, json={
        "type": "line", "name": "L", "params": {"points": [[0, .5], [1, .5]], "classes": ["person"]}})
    assert rule.status_code == 201
    assert client.post(f"/api/cameras/{cid}/rules", headers=h, json={"type": "zone", "name": "z", "params": {"points": []}}).status_code == 422
    assert len(client.get(f"/api/cameras/{cid}/rules", headers=h).json()) == 1
    assert client.get("/api/events", headers=h).json() == []
    assert client.get("/api/stats/counts", headers=h).json()["rows"] == []
    assert client.get("/api/system", headers=h).json()["cameras"]["total"] == 1
    assert client.delete(f"/api/cameras/{cid}", headers=h).status_code == 204


def test_ui_is_served(client):
    r = client.get("/")
    assert r.status_code == 200 and "data-theme" in r.text
